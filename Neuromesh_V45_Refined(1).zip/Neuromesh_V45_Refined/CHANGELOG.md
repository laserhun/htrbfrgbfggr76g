# Neuromesh V4.5 — short changelog

- Kept V4's control-cage kernel and five supertools. Added shared root densification, smaller attachment footprints, shaped section profiles, and bisector frames for bent joints.
- Added triangle-point brush seeding, elliptical/facing masks, adjustable falloff and displacement caps.
- Improved duplicate-face repair, individual component orientation and post-repair validation. Binned intersection queries avoid unnecessary global-radius candidate work.
- Improved the existing annotated-reference fitter with bounds, robust loss and subdivision-aware ring landmarks. No new reconstruction network or raw-photo solver.

**Evidence:** 29 tests passed. Both V4.5 meshes have one closed skin, positive volume, no boundary/nonmanifold/duplicate/degenerate faces, consistent winding, and zero measured transverse crossings. Six-view renders and GLBs are included.

**Compared with V4:** the cat uses a slimmer torso and shorter facial profile; limbs use denser/shaped sections. The capuchin uses a short muzzle, a lighter torso, opposing thumbs, a curled tail and smaller ear roots. The V4 comparison capuchin was rejected for intersections; its diagnostic export has 45 measured crossing pairs. It is clearly labeled as a failed baseline. Comparisons have matched cameras and neutral materials.

**Limit:** both models still look simplified and retain primitive-looking faces/paws. Convincing realistic anatomy is not achieved. More geometry did not establish realism. V4.5 is also not universally faster: the cat takes longer because of its denser cages and facial strokes. Arbitrary intersection repair, photo reconstruction, fur, UVs and animation-ready topology remain unavailable.
