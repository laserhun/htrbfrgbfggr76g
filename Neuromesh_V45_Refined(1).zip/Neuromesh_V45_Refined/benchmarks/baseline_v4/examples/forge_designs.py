"""Authored anatomical controls, not kernel-specific species templates.
Coordinates X lateral, Y nose-to-tail, Z height. Base forms only.
"""
import copy,json
from pathlib import Path


def document(name,profiles):
    return {'ngl_version':2,'name':name,'settings':{'detail':'medium','subdivision':2,'max_faces':160000,'max_memory_mb':512,'max_cache_mb':64},
            'cage':{'ring_vertices':8,'sections':[{'id':ident,'center':[0,y,z],'radii':[w,h]} for ident,y,z,w,h in profiles],'branches':[]},'surface_strokes':[]}


def branch(d,ident,attach,points):d['cage']['branches'].append({'id':ident,'attach':attach,'sections':points})


def add_skeleton(d):
    joints={};bones=[]
    for b in d['cage']['branches']:
        if b.get('relative'):continue
        controls=[]
        previous=None
        for i,q in enumerate(b['sections']):
            ident=f"{b['id']}_joint_{i}";joints[ident]=q[:3];controls.append({'joint':ident,'radii':q[3:]})
            if previous:bones.append({'id':ident+'_bone','start':previous,'end':ident})
            previous=ident
        b['sections']=controls
    d['skeleton']={'joints':joints,'bones':bones}


def cat():
    d=document('Forge cat — unadorned anatomical cage',[
       ('nose',-1.16,1.30,.065,.052),('muzzle',-1.10,1.30,.125,.092),('cheek',-.99,1.38,.235,.205),
       ('skull',-.85,1.43,.248,.230),('occiput',-.70,1.40,.210,.218),('neck',-.59,1.27,.173,.223),
       ('withers',-.44,1.09,.235,.287),('scapula',-.26,1.035,.253,.303),('ribs',-.03,.99,.260,.307),
       ('waist',.24,.95,.224,.256),('pelvis',.45,.95,.274,.290),('sacrum',.65,.98,.220,.215),
       ('tail_root',.77,1.02,.082,.09),('tail_1',.96,1.13,.065,.067),('tail_2',1.15,1.38,.052,.055),
       ('tail_3',1.20,1.64,.040,.043),('tail_tip',1.06,1.81,.012,.015)])
    # Root faces are replaced by legs, sharing all root vertices with torso.
    for s,label,angle in [(1,'right',7),(-1,'left',4)]:
        branch(d,label+'_foreleg','withers:'+str(angle),[[s*.253,-.365,.76,.115,.108],[s*.250,-.37,.53,.074,.071],
               [s*.248,-.415,.27,.071,.069],[s*.248,-.435,.135,.068,.063],[s*.248,-.535,.103,.108,.092],[s*.248,-.620,.103,.088,.071]])
        branch(d,label+'_hindleg','pelvis:'+str(angle),[[s*.282,.48,.74,.153,.135],[s*.30,.25,.50,.094,.087],
               [s*.30,.46,.29,.080,.078],[s*.30,.43,.14,.070,.064],[s*.30,.31,.100,.105,.093],[s*.30,.21,.10,.083,.073]])
        branch(d,label+'_ear','skull:'+str(0 if s==1 else 3),[[s*.182,-.79,1.64,.113,.073],
               [s*.208,-.75,1.77,.078,.037],[s*.22,-.74,1.80,.012,.015]])
    # Coarse silhouette correction: compact neck, full shoulder/thigh transitions,
    # shorter lower legs and broad load-bearing paws. No surface embellishment.
    for q in d['cage']['sections']:
        q['center'][2]-=.12
        if q['id'] in ('withers','scapula'):q['radii'][0]*=1.12
        if q['id']=='pelvis':q['radii'][0]*=1.08
        if q['id'] in ('cheek','skull'):
            q['radii'][0]*=1.07;q['radial']=[1.05,.95,.98,.95,1.05,.95,.96,.95]
    for b in d['cage']['branches']:
        if b['id'].endswith('ear'):
            for q in b['sections']:q[2]-=.12
        else:
            for q in b['sections']:
                q[2]=.1+(q[2]-.1)*.84
            b['sections'][0][3]*=1.42;b['sections'][0][4]*=1.32
            b['sections'][1][3]*=1.18;b['sections'][1][4]*=1.18
    add_skeleton(d)
    return d


def baboon():
    d=document('Forge baboon — continuous mantle, prognathic skull, articulated limbs',[
       ('nose',-1.44,1.10,.11,.078),('muzzle_tip',-1.36,1.11,.155,.103),('muzzle',-1.13,1.18,.17,.145),
       ('brow',-.98,1.38,.212,.202),('skull',-.80,1.47,.238,.242),('occiput',-.61,1.44,.233,.265),
       ('neck',-.48,1.29,.270,.350),('withers',-.34,1.18,.295,.375),('scapula',-.13,1.12,.305,.357),
       ('ribs',.13,1.00,.279,.302),('waist',.35,.95,.228,.248),('pelvis',.55,.93,.265,.268),
       ('sacrum',.74,.92,.189,.180),('tail_root',.86,1.02,.08,.078),('tail_1',1.04,1.32,.06,.064),
       ('tail_2',1.28,1.57,.051,.047),('tail_tip',1.62,1.50,.015,.018)])
    for s,label,angle in [(1,'right',7),(-1,'left',4)]:
        branch(d,label+'_arm','withers:'+str(angle),[[s*.32,-.29,.80,.135,.119],[s*.34,-.44,.55,.089,.086],
               [s*.35,-.69,.28,.064,.066],[s*.36,-.84,.13,.06,.052],[s*.36,-.95,.095,.089,.047],[s*.36,-1.06,.094,.088,.038]])
        branch(d,label+'_leg','pelvis:'+str(angle),[[s*.30,.61,.71,.161,.150],[s*.32,.74,.48,.092,.107],
               [s*.33,.60,.26,.068,.077],[s*.33,.70,.13,.055,.06],[s*.33,.57,.095,.10,.053],[s*.33,.45,.09,.089,.042]])
        branch(d,label+'_ear','skull:'+str(7 if s==1 else 4),[[s*.295,-.79,1.48,.078,.077],[s*.35,-.79,1.49,.063,.060],[s*.365,-.79,1.50,.045,.044]])
    # Four finger roots partition the distal palm cap, with shared strip edges.
    for s,label in [(1,'right'),(-1,'left')]:
        for digit in range(4):
            branch(d,f'{label}_digit_{digit}',f'{label}_arm:cap:strip:{digit}',[[0,-.055,0,.018,.016],[0,-.11,-.007,.017,.015],[0,-.165,-.002,.010,.010]])
            d['cage']['branches'][-1]['relative']=True
    add_skeleton(d)
    return d


def creature():
    d=document('Forge unfamiliar organism — six articulated lobes with nested branches',[
       ('beak',-.87,1.16,.045,.07),('head',-.71,1.15,.23,.25),('collar',-.45,1.05,.29,.31),
       ('thorax',-.21,.99,.34,.36),('viscera',.10,.98,.40,.34),('waist',.37,1.01,.25,.29),
       ('pelvis',.62,1.10,.32,.31),('stem',.85,1.24,.15,.15),('crown',1.07,1.39,.07,.08),('tip',1.18,1.49,.015,.018)])
    d['cage']['sections'][4]['center'][0]=.095
    d['cage']['sections'][2]['radial']=[1,.83,1.1,.84,1.15,1,1.12,.87]
    for j,root in enumerate(['collar','viscera','pelvis']):
        for s,label,k in [(1,'right',7),(-1,'left',4)]:
            y=-.42+j*.52;name=f'{label}_limb_{j}'
            branch(d,name,f'{root}:{k}',[[s*.48,y,.73,.145,.128],[s*.72,y-.18,.52,.103,.090],
                   [s*.86,y-.05,.26,.066,.056],[s*.99,y+.10,.14,.052,.043],[s*1.13,y+.13,.21,.031,.028],[s*1.19,y+.03,.34,.009,.012]])
            branch(d,name+'_fork',name+':2:auto',[[s*1.02,y-.30,.39,.048,.042],[s*1.19,y-.42,.48,.029,.025],[s*1.28,y-.41,.65,.006,.008]])
    branch(d,'dorsal_sail','thorax:1',[[.04,-.07,1.49,.21,.115],[.14,.11,1.73,.19,.08],[.19,.27,1.87,.05,.024]])
    return d


if __name__=='__main__':
    for name,fn in [('cat',cat),('baboon',baboon),('creature',creature)]:
        Path(__file__).with_name(name+'.v4.ngl.json').write_text(json.dumps(fn(),indent=2))
