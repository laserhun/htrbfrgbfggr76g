"""Editable benchmark NGL designs. All shapes are executed by the generic kernel."""
import json
from pathlib import Path
import numpy as np


def design(name):
    return {'ngl_version':1,'name':name,'settings':{'voxel':.036,'detail':'high','brick':24,
        'max_cells':8_000_000,'min_feature_voxels':.85,'group_voxel':{'eye_white':.016,'iris':.012,'pupil':.010},'max_memory_mb':512,'max_cache_mb':160,'continuous_bones':True,
        'colors':{'flesh':[96,69,46],'eye_white':[87,67,40],'iris':[163,116,37],
        'pupil':[8,9,8],'inner_ear':[57,42,37],'lip':[48,32,31],'detail':[110,78,58]}},'parts':[]}


def add(doc,name,points,blend=.08,stage='primary',group='flesh',role='solid',**extra):
    doc['parts'].append(dict(id=name,kind='loft',points=points,blend=blend,stage=stage,group=group,role=role,**extra))


def ell(doc,name,center,radii,group='flesh',role='solid',stage='secondary',blend=.03,**extra):
    doc['parts'].append(dict(id=name,kind='ellipsoid',center=center,radii=radii,group=group,role=role,stage=stage,blend=blend,**extra))


def baboon():
    d=design('Rebirth baboon — quadrupedal musculoskeletal silhouette')
    add(d,'ribcage',[[0,.58,.91,.27,.24],[0,.28,1.02,.32,.34],[0,-.08,1.12,.35,.39],[0,-.36,1.19,.29,.35]],.16)
    add(d,'neck_mantle',[[0,-.26,1.11,.28,.30],[0,-.44,1.27,.31,.34],[0,-.61,1.38,.23,.25]],.16)
    add(d,'cranium',[[0,-.57,1.35,.19,.22],[0,-.74,1.43,.265,.24],[0,-.88,1.40,.21,.19]],.1)
    add(d,'face_bridge',[[0,-.82,1.35,.205,.18],[0,-1.03,1.22,.18,.145],[0,-1.28,1.115,.17,.12],[0,-1.43,1.09,.14,.105]],.08)
    add(d,'lower_jaw',[[0,-.74,1.18,.18,.15],[0,-1.02,1.04,.165,.105],[0,-1.31,1.00,.145,.06]],.07)
    ell(d,'facial_skin',[0,-1.08,1.31],[.29,.64,.29],role='paint',color=[105,91,78],falloff=.04)
    ell(d,'nose_color',[0,-1.51,1.09],[.16,.10,.095],role='paint',color=[51,44,40],falloff=.025)
    # Actual shallow oral cavity and nasal depressions in one continuous skin shell.
    add(d,'oral_cavity',[[-.12,-1.40,1.015,.12,.025],[0,-1.445,1.005,.135,.03],[.12,-1.40,1.015,.12,.025]],.008,'secondary',role='cut')
    for sign in (-1,1):
        label='left' if sign<0 else 'right'
        ell(d,label+'_nostril',[sign*.072,-1.535,1.12],[.038,.06,.031],role='cut',blend=.006)
        ell(d,label+'_socket',[sign*.19,-.997,1.413],[.095,.087,.083],role='cut',blend=.012)
        ell(d,label+'_orbital_paint',[sign*.19,-.97,1.42],[.135,.12,.11],role='paint',color=[54,45,37],falloff=.025)
        ell(d,label+'_eye',[sign*.19,-.977,1.415],[.059,.055,.053],'eye_white')
        ell(d,label+'_iris',[sign*.19,-1.026,1.415],[.028,.013,.029],'iris',blend=.005)
        ell(d,label+'_pupil',[sign*.19,-1.036,1.415],[.012,.008,.013],'pupil',blend=.002)
        add(d,label+'_brow',[[sign*.09,-.989,1.484,.045,.037],[sign*.19,-.978,1.495,.05,.038],[sign*.27,-.923,1.474,.042,.033]],.04,'secondary')
        ell(d,label+'_ear',[sign*.278,-.704,1.434],[.092,.045,.12],blend=.04)
        ell(d,label+'_ear_well',[sign*.295,-.736,1.448],[.057,.035,.078],role='cut',blend=.008)
        ell(d,label+'_ear_skin',[sign*.30,-.735,1.447],[.07,.065,.097],role='paint',color=[55,45,39],falloff=.02)
        add(d,label+'_scapula',[[sign*.25,-.25,1.23,.15,.17],[sign*.31,-.37,1.00,.14,.18],[sign*.34,-.44,.81,.105,.12]],.12)
        add(d,label+'_arm',[[sign*.29,-.31,1.12,.12,.135],[sign*.34,-.47,.76,.095,.125],[sign*.36,-.64,.45,.08,.09],[sign*.39,-.84,.19,.071,.068]],.07)
        add(d,label+'_hand',[[sign*.39,-.80,.19,.075,.06],[sign*.39,-.91,.13,.10,.05],[sign*.39,-1.01,.115,.08,.043]],.06)
        for digit in range(4):
            x=sign*.39+(digit-1.5)*.038
            add(d,f'{label}_finger_{digit}',[[x,-.985,.13,.028,.026],[x,-1.06,.11,.024,.024],[x+(digit-1.5)*.010,-1.14,.105,.018,.02]],.025,'secondary')
        add(d,label+'_thumb',[[sign*.32,-.91,.15,.039,.034],[sign*.28,-.98,.13,.028,.027],[sign*.26,-1.02,.12,.02,.025]],.03,'secondary')
        # Thigh/calf/hock paths preserve the characteristic rear-leg bend.
        add(d,label+'_hip',[[sign*.20,.48,.95,.18,.21],[sign*.31,.57,.76,.19,.23],[sign*.34,.73,.58,.13,.15]],.14)
        add(d,label+'_hind_leg',[[sign*.31,.59,.78,.14,.16],[sign*.34,.76,.51,.105,.125],[sign*.35,.67,.31,.071,.09],[sign*.36,.79,.13,.073,.067]],.075)
        add(d,label+'_foot',[[sign*.36,.80,.14,.081,.075],[sign*.36,.66,.11,.102,.055],[sign*.36,.52,.105,.088,.042]],.045)
        for digit in range(3):
            x=sign*.36+(digit-1)*.047
            add(d,f'{label}_toe_{digit}',[[x,.58,.12,.036,.03],[x,.49,.105,.030,.025],[x,.43,.10,.018,.02]],.025,'secondary')
        for ridge in range(4):
            x=sign*(.08+ridge*.055)
            add(d,f'{label}_mantle_fold_{ridge}',[[x,-.51,1.58,.039,.037],[x*1.18,-.40,1.50,.046,.041],[x*1.25,-.30,1.37,.035,.03]],.035,'detail')
    add(d,'tail',[[0,.61,.96,.105,.105],[0,.92,1.02,.095,.095],[.03,1.12,1.29,.08,.08],[.08,1.32,1.56,.065,.065],[.10,1.59,1.62,.053,.053],[.06,1.84,1.46,.028,.03]],.08)
    # Skeleton landmarks remain available to reference fitting; muscles define silhouettes.
    d['skeleton']={'joints':{'withers':[0,-.3,1.2],'hip':[0,.55,.88],'crown':[0,-.7,1.58]},'bones':[]}
    return d


def creature():
    d=design('Rebirth parasite — asymmetric connective tissue and curved musculature')
    d['settings']['colors'].update(flesh=[131,57,65],eye_white=[232,215,164],iris=[192,149,31],detail=[176,88,100])
    add(d,'visceral_trunk',[[.12,.25,-.65,.30,.34],[-.11,.08,-.3,.49,.43],[.08,-.04,.12,.56,.45],[.03,.13,.48,.39,.34],[-.17,.18,.71,.16,.20]],.16)
    add(d,'twisted_mantle',[[-.5,.18,-.5,.20,.26],[-.54,.14,-.05,.34,.36],[-.34,.05,.36,.37,.32],[.12,.18,.63,.25,.26],[.53,.22,.32,.24,.22]],.13)
    add(d,'lower_flesh_apron',[[-.42,.07,-.52,.17,.20],[.05,-.15,-.67,.34,.27],[.43,-.04,-.37,.21,.23]],.13)
    # Smooth volumetric cavity, with rim anatomy created by the remaining shell.
    add(d,'open_gullet',[[0,-.40,-.42,.16,.21],[.05,-.45,-.13,.23,.25],[-.015,-.42,.19,.14,.16]],.025,'secondary',role='cut')
    ell(d,'gullet_pigment',[.02,-.45,-.06],[.31,.21,.43],role='paint',color=[48,14,27],falloff=.04)
    for i,(x,z,r) in enumerate([(-.30,.40,.13),(.34,.19,.115),(-.35,-.12,.095),(.09,.69,.105)]):
        ell(d,f'eye_socket_{i}',[x,-.35,z],[r*1.15,.15,r*1.18],role='cut',blend=.018)
        ell(d,f'eye_globe_{i}',[x,-.325,z],[r,.09,r],'eye_white')
        ell(d,f'iris_{i}',[x,-.41,z],[r*.52,.025,r*.61],'iris',blend=.008)
        ell(d,f'pupil_{i}',[x,-.432,z],[r*.12,.013,r*.46],'pupil',blend=.004)
    roots=[]
    for i,a in enumerate([-.18,.62,1.12,1.72,2.54,3.34,4.01,4.75,5.63]):
        root=np.array([.34*np.cos(a),.08,.38*np.sin(a)])
        length=1.45+.34*np.sin(i*1.74+.3)
        end=np.array([length*np.cos(a),.12+.20*np.sin(i),length*.93*np.sin(a)])
        mid=root*.3+end*.7+np.array([.19*np.sin(i),.16,-.10])
        points=[[*root,.16,.13],[*(root*.6+end*.4+np.array([.13*np.sin(i),-.13,.07])),.14,.105],
          [*mid,.095,.075],[*(end+np.array([.06,.14,-.12])),.065,.055],
          [*(end+np.array([-.19*np.sin(a),.02,.22*np.cos(a)])),.024,.026]]
        add(d,f'primary_tendon_{i}',points,.115)
        branch=mid+np.array([.20*np.sin(a),-.14,.23*np.cos(a)])
        tip=branch+np.array([.39*np.cos(a+.6),-.19,.45*np.sin(a+.6)])
        add(d,f'branch_{i}',[[*mid,.072,.061],[*branch,.054,.05],[*tip,.016,.02]],.06,'secondary')
        # Surface ridge runs on the tendon's anterior side; connects into its body.
        ridge=[]
        for p in points[1:-1]:
            ridge.append([p[0],p[1]-p[4]*.76,p[2],p[3]*.32,p[4]*.28])
        add(d,f'tendon_ridge_{i}',ridge,.026,'detail')
        roots.append(root)
    # Interconnected asymmetric loops form hollow negative spaces without detached balls.
    for i in range(3):
        x=.32*(-1 if i%2 else 1);z=-.4+i*.33
        add(d,f'connective_loop_{i}',[[x,.05,z,.10,.09],[x*2.3,-.05,z+.25,.087,.07],
              [x*3.1,.12,z+.44,.075,.06],[x*1.4,.23,z+.63,.10,.08],[x*.6,.1,z+.48,.13,.105]],.08,'secondary')
    for i in range(4):
        sign=-1 if i%2 else 1;z=-.40+i*.21
        add(d,f'fascia_arch_{i}',[[sign*.23,-.13,z,.087,.071],[sign*.68,-.37,z-.10,.085,.057],
              [sign*.81,-.46,z+.23,.071,.058],[sign*.46,-.44,z+.43,.067,.054],
              [sign*.10,-.12,z+.31,.086,.065]],.075,'secondary')
    for i in range(7):
        z=-.45+i*.135
        add(d,f'visceral_fold_{i}',[[-.22,-.31,z,.045,.039],[.03,-.36,z+.036,.061,.047],[.29,-.26,z+.08,.042,.039]],.025,'detail')
    return d


if __name__=='__main__':
    out=Path(__file__).parent
    for name,factory in [('baboon',baboon),('creature',creature)]:
        (out/f'{name}.ngl.json').write_text(json.dumps(factory(),indent=2))
        print(name,len(factory()['parts']))
