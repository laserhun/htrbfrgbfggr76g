"""CPU depth-buffer rasterizer. Pixel ownership uses per-pixel depth, not face-average ordering."""
from pathlib import Path
import numpy as np
import trimesh
from PIL import Image, ImageDraw, ImageFont

BACKGROUND=np.array([23,19,29],dtype=np.uint8)

def render_views(glb_path,out,max_faces=150000,size=640,framing=None):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    scene=trimesh.load(glb_path,force='scene')
    meshes=[]
    for name,mesh in scene.geometry.items():
        if not isinstance(mesh,trimesh.Trimesh):continue
        col=np.asarray(mesh.visual.vertex_colors)[:,:3]/255 if hasattr(mesh.visual,'vertex_colors') else np.array([.65,.4,.4])
        meshes.append((name,mesh,np.asarray(col)))
    vv=np.concatenate([m.vertices for _,m,_ in meshes]);center=(vv.min(axis=0)+vv.max(axis=0))*.5
    span=max(np.ptp(vv[:,0]),np.ptp(vv[:,1]),np.ptp(vv[:,2]))*1.15
    if framing is not None:
        center=np.asarray(framing['center']);span=float(framing['span'])
    views={'front':(180,0),'left':(90,0),'right':(270,0),'rear':(0,0),'top':(180,89.9),'three_quarter':(140,18)}
    paths=[]
    for name,(az,el) in views.items():
        az,el=np.deg2rad([az,el]);ca,sa=np.cos(az),np.sin(az);ce,se=np.cos(el),np.sin(el)
        right=np.array([ca,-sa,0]);up=np.array([sa*se,ca*se,ce]);toward=np.array([sa*ce,ca*ce,-se])
        basis=np.stack([right,up,toward],axis=1)
        framebuffer=np.tile(BACKGROUND,(size,size,1));zbuffer=np.full((size,size),-np.inf,np.float32)
        for _,mesh,base in meshes:
            f=mesh.faces
            if len(f)>max_faces:
                raise ValueError(f'Mesh has {len(f)} faces; raise max_faces. Skipping faces creates false holes.')
            v=(mesh.vertices-center)@basis
            vn=np.asarray(mesh.vertex_normals)@basis
            xy=np.column_stack((v[:,0]/span*size+size*.5, size*.5-v[:,1]/span*size))
            for a,b,c in f:
                tri=xy[[a,b,c]];z=v[[a,b,c],2]
                if not np.isfinite(tri).all():continue
                if tri[:,0].max()<0 or tri[:,0].min()>=size or tri[:,1].max()<0 or tri[:,1].min()>=size:continue
                x0,y0=tri[0];x1,y1=tri[1];x2,y2=tri[2]
                den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2)
                if abs(den)<1e-10:continue
                xmin=max(0,int(np.floor(tri[:,0].min())));xmax=min(size-1,int(np.ceil(tri[:,0].max())))
                ymin=max(0,int(np.floor(tri[:,1].min())));ymax=min(size-1,int(np.ceil(tri[:,1].max())))
                if xmax<xmin or ymax<ymin:continue
                yy,xx=np.mgrid[ymin:ymax+1,xmin:xmax+1]
                xx=xx.ravel();yy=yy.ravel();xxp=xx+.5;yyp=yy+.5
                w0=((y1-y2)*(xxp-x2)+(x2-x1)*(yyp-y2))/den
                w1=((y2-y0)*(xxp-x2)+(x0-x2)*(yyp-y2))/den
                w2=1-w0-w1
                covered=(w0>=-1e-5)&(w1>=-1e-5)&(w2>=-1e-5)
                if not covered.any():continue
                xx=xx[covered];yy=yy[covered];w0=w0[covered];w1=w1[covered];w2=w2[covered]
                depth=(w0*z[0]+w1*z[1]+w2*z[2]).astype(np.float32)
                win=depth>zbuffer[yy,xx]
                if not win.any():continue
                ns=w0[:,None]*vn[a]+w1[:,None]*vn[b]+w2[:,None]*vn[c]
                ns/=np.maximum(np.linalg.norm(ns,axis=1)[:,None],1e-10)
                light=np.clip(.48+.5*np.abs(ns@np.array([-.45,.35,.82])),.16,1.)
                base_pixel=w0[:,None]*base[a]+w1[:,None]*base[b]+w2[:,None]*base[c] if base.ndim==2 else base[None,:]
                colors=(np.clip(base_pixel*light[:,None]+.035,0,1)*255).astype(np.uint8)
                framebuffer[yy[win],xx[win]]=colors[win];zbuffer[yy[win],xx[win]]=depth[win]
        image=Image.fromarray(framebuffer,'RGB')
        path=out/f'{name}.png';image.save(path);paths.append(path)
    sheet=Image.new('RGB',(size*3,size*2),tuple(BACKGROUND))
    draw=ImageDraw.Draw(sheet)
    for i,p in enumerate(paths):
        x,y=(i%3)*size,(i//3)*size
        sheet.paste(Image.open(p),(x,y));draw.text((x+14,y+14),list(views)[i].replace('_',' ').title(),fill=(230,225,220),stroke_width=1,stroke_fill=(20,18,23))
    sheet.save(out/'multiview.png')
    return {'views':[str(p) for p in paths],'sheet':str(out/'multiview.png'),'renderer':'CPU per-pixel depth buffer','size':size}
