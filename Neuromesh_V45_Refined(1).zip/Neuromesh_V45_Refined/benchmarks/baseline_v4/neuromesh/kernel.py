"""Continuous, anisotropic medial-curve lofts; no AI or GPU dependencies."""
from functools import lru_cache
import json
import numpy as np
from scipy.interpolate import CubicSpline, PchipInterpolator


@lru_cache(maxsize=256)
def _curve(serialized, spacing, up):
    controls = np.asarray(json.loads(serialized), dtype=float)
    chord = np.linalg.norm(np.diff(controls[:, :3], axis=0), axis=1)
    if np.any(chord < 1e-6):
        raise ValueError('Loft controls must have distinct consecutive positions')
    t = np.r_[0, np.cumsum(chord)]
    count = min(128, max(3, int(np.ceil(t[-1] / spacing)) + 1))
    s = np.linspace(0, t[-1], count)
    spline = CubicSpline(t, controls[:, :3], axis=0, bc_type='natural')
    centers = spline(s)
    tangent = spline(s, 1)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1)[:, None], 1e-9)
    radii = np.exp(PchipInterpolator(t, np.log(controls[:, 3:5]), axis=0)(s))
    # Transport the transverse axis rather than reselecting a world axis on each segment.
    frames = []
    u = np.cross(tangent[0], np.asarray(up))
    if np.linalg.norm(u) < 1e-5:
        u = np.cross(tangent[0], np.eye(3)[np.argmin(abs(tangent[0]))])
    u /= np.linalg.norm(u)
    for direction in tangent:
        u = u - np.dot(u, direction) * direction
        if np.linalg.norm(u) < 1e-6:
            raise ValueError('Loft tangent reverses too sharply; add intermediate controls')
        u /= np.linalg.norm(u)
        frames.append(np.stack((u.copy(), np.cross(direction, u))))
    return centers.astype('f4'), radii.astype('f4'), np.asarray(frames, dtype='f4')


def prepare_loft(part):
    spacing = float(part.get('curve_spacing', .09))
    if not .02 <= spacing <= .4:
        raise ValueError('curve_spacing must be .02–.4')
    return _curve(json.dumps(part['points']), spacing, tuple(part.get('up', [0, 0, 1])))


def loft_bounds(part):
    centers, radii, _ = prepare_loft(part)
    reach = np.max(radii, axis=1)
    return (centers - reach[:, None]).min(0), (centers + reach[:, None]).max(0)


def loft_field(part, xyz):
    centers, radii, frames = prepare_loft(part)
    result = np.full(xyz.shape[:-1], np.inf, dtype='f4')
    for i in range(len(centers) - 1):
        a, b = centers[i:i+2]
        delta = b-a
        length = float(np.linalg.norm(delta))
        if length < 1e-7:
            continue
        tangent = delta/length
        rel = xyz-a
        axial = np.sum(rel*tangent, axis=-1)
        t = np.clip(axial/length, 0, 1)
        residual = rel-t[..., None]*delta
        u = frames[i, 0] + t[..., None]*(frames[i+1, 0]-frames[i, 0])
        u -= np.sum(u*tangent, axis=-1)[..., None]*tangent
        u /= np.maximum(np.linalg.norm(u, axis=-1)[..., None], 1e-9)
        v = np.cross(tangent, u)
        r = radii[i]+t[..., None]*(radii[i+1]-radii[i])
        # Rounded elliptical caps; radius interpolation is shape-preserving.
        qx = np.sum(residual*u, axis=-1)/r[..., 0]
        qy = np.sum(residual*v, axis=-1)/r[..., 1]
        qz = np.sum(residual*tangent, axis=-1)/np.sqrt(r[..., 0]*r[..., 1])
        distance = (np.sqrt(qx*qx+qy*qy+qz*qz)-1)*np.minimum(r[..., 0], r[..., 1])
        result = np.minimum(result, distance)
    return result
