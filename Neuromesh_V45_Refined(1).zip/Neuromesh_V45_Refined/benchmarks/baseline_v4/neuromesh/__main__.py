import argparse,json
from pathlib import Path
from .engine import Engine

def main():
    p=argparse.ArgumentParser(prog='neuromesh',description='CPU geometric NGL engine')
    p.add_argument('--project',default='parasite_project',help='Project folder with model and versions')
    sub=p.add_subparsers(dest='command',required=True)
    a=sub.add_parser('generate');a.add_argument('ngl');a.add_argument('--detail',choices=['draft','medium','high'])
    a=sub.add_parser('modify');a.add_argument('edits',help='JSON file containing a list of edits')
    a=sub.add_parser('refine');a.add_argument('--detail',default='high',choices=['draft','medium','high']);a.add_argument('--voxel',type=float)
    a=sub.add_parser('inspect');a.add_argument('--max-faces',type=int,default=150000)
    a=sub.add_parser('export');a.add_argument('destination');a.add_argument('--format',choices=['glb','obj'],default='glb')
    a=sub.add_parser('rollback');a.add_argument('version')
    a=sub.add_parser('doctor');a.add_argument('input_glb');a.add_argument('output_glb')
    a=sub.add_parser('sculpt');a.add_argument('modifier',help='One modifier JSON file')
    sub.add_parser('report')
    args=p.parse_args(); e=Engine(args.project)
    if args.command=='generate': r=e.generate(json.loads(Path(args.ngl).read_text()),args.detail)
    elif args.command=='modify': r=e.modify(json.loads(Path(args.edits).read_text()))
    elif args.command=='refine': r=e.refine(args.detail,args.voxel)
    elif args.command=='inspect': r=e.inspect(args.max_faces)
    elif args.command=='export': r={'path':e.export(args.destination,args.format)}
    elif args.command=='rollback': r=e.rollback(args.version)
    elif args.command=='doctor':
        from .doctor import neuro_doctor
        r=neuro_doctor(args.input_glb,args.output_glb,Path(args.output_glb).with_suffix('.report.json'))
    elif args.command=='sculpt':
        from .engine import neuro_sculpt
        r=neuro_sculpt(args.project,json.loads(Path(args.modifier).read_text()))
    else: r=json.loads((e.root/'build'/'report.json').read_text())
    print(json.dumps(r,indent=2))
if __name__=='__main__':main()
