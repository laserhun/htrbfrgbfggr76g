"""Reusable landmark and articulated-limb helpers for ChatGPT-authored NGL."""
import numpy as np

class Anatomy:
    def __init__(self,name='creature',settings=None):
        self.doc={'ngl_version':1,'name':name,'settings':settings or {'detail':'medium','max_cells':6000000},'parts':[],
                  'skeleton':{'joints':{},'bones':[]}}
    def joint(self,name,xyz):
        self.doc['skeleton']['joints'][name]=[float(v) for v in xyz]
    def bone(self,name,start,end,r0,r1,blend=.1):
        self.doc['skeleton']['bones'].append({'id':name,'start':start,'end':end,
             'radii_start':[float(x) for x in r0],'radii_end':[float(x) for x in r1], 'blend':blend})
    def ellipsoid(self,name,center,radii,group='flesh',blend=.1,roughness=0):
        self.doc['parts'].append({'id':name,'kind':'ellipsoid','center':list(map(float,center)),
            'radii':list(map(float,radii)),'group':group,'blend':blend,'roughness':roughness})
    def muscle(self,name,points,group='flesh',blend=.1,roughness=0):
        self.doc['parts'].append({'id':name,'kind':'anatomy_sweep','points':[list(map(float,p)) for p in points],
            'group':group,'blend':blend,'roughness':roughness})
    def sweep(self,name,points,group='detail',blend=.04):
        self.doc['parts'].append({'id':name,'kind':'sweep','points':[list(map(float,p)) for p in points],
            'group':group,'blend':blend})
    def articulated_hand(self,prefix,wrist,palm_scale=.12,finger_length=.24,color='flesh',spread=1):
        w=np.asarray(wrist,dtype=float);self.ellipsoid(prefix+'_palm',w,[palm_scale*1.12,palm_scale*.52,palm_scale*1.35],color,.08)
        for digit in range(4):
            x=(digit-1.5)*palm_scale*.82*spread
            root=w+np.array([x,-palm_scale*.28,-palm_scale*.60])
            direction=(digit-1.5)*.12*spread;points=[]
            for k in range(4):
                t=k/3
                points.append([*(root+np.array([direction*t,-finger_length*.18*t,-finger_length*t])),palm_scale*(.23-.16*t),palm_scale*(.2-.14*t)])
            self.muscle(f'{prefix}_finger_{digit}',points,color,.035)
        root=w+np.array([-palm_scale*.9,-palm_scale*.06,-palm_scale*.16])
        pts=[[*root,palm_scale*.22,palm_scale*.2],
             [*(root+np.array([-.12,-finger_length*.42,-finger_length*.3])),palm_scale*.18,palm_scale*.16],
             [*(root+np.array([-.20,-finger_length*.7,-finger_length*.35])),palm_scale*.13,palm_scale*.12]]
        self.muscle(prefix+'_opposing_thumb',pts,color,.035)
    def build(self):return self.doc
