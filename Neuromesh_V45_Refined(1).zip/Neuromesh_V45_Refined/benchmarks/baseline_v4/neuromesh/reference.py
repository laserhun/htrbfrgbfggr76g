"""Camera-aware fitting to user/ChatGPT annotated 2D image landmarks."""
import copy
import numpy as np
from scipy.optimize import least_squares
from .engine import validate_ngl


def loft_from_silhouettes(part_id, front, side, group='flesh'):
    """Build a vertical profile from annotated orthographic contours in world units.

    Each view is a list of [height, left_bound, right_bound]. This fits elliptical
    cross sections to two explicitly supplied contours, not inferred image pixels.
    """
    from scipy.interpolate import PchipInterpolator
    front,side=np.asarray(front,float),np.asarray(side,float)
    for contour in (front,side):
        if contour.ndim!=2 or contour.shape[1]!=3 or len(contour)<2:
            raise ValueError('Contours require at least two [height, min, max] samples')
        if np.any(np.diff(contour[:,0])<=0) or np.any(contour[:,2]<=contour[:,1]):
            raise ValueError('Heights must increase and widths must be positive')
    low=max(front[0,0],side[0,0]);high=min(front[-1,0],side[-1,0])
    if low>=high: raise ValueError('Contours have no shared height range')
    heights=np.unique(np.r_[front[:,0],side[:,0],low,high])
    heights=heights[(heights>=low)&(heights<=high)]
    x=PchipInterpolator(front[:,0],front[:,1:])(heights)
    y=PchipInterpolator(side[:,0],side[:,1:])(heights)
    return {'id':part_id,'kind':'profile_sweep','group':group,'blend':.1,
            'points':np.column_stack((x.mean(1),y.mean(1),heights,np.diff(x,axis=1)[:,0]/2,np.diff(y,axis=1)[:,0]/2)).tolist()}


def fit_landmarks(ngl, observations, *, pixels_per_unit, image_size, regularization=.05):
    """Fit named part centers to annotated front/side pixels; return edited NGL.

    Camera: orthographic, centered image; front projects [-X,+Z], left projects [-Y,+Z].
    Each observation is {id, pixel:[u,v], view:'front'|'left', weight:1}.
    """
    doc=copy.deepcopy(validate_ngl(ngl));parts={p['id']:p for p in doc['parts']}
    ids=list(dict.fromkeys(o['id'] for o in observations))
    if not ids or any(i not in parts for i in ids):raise ValueError('Observations need known part IDs')
    if pixels_per_unit<=0 or min(image_size)<=0:raise ValueError('Invalid camera scale')
    def origin(p):
        return np.asarray(p['center'] if p['kind']=='ellipsoid' else p['points'][0][:3],dtype=float)
    base=np.array([origin(parts[i]) for i in ids]);index={ident:j for j,ident in enumerate(ids)}
    def residual(delta):
        centers=base+delta.reshape(-1,3)
        errors=[]
        for o in observations:
            c=centers[index[o['id']]];v=o.get('view','front')
            if v=='front': uv=[image_size[0]/2-c[0]*pixels_per_unit,image_size[1]/2-c[2]*pixels_per_unit]
            elif v=='left':uv=[image_size[0]/2-c[1]*pixels_per_unit,image_size[1]/2-c[2]*pixels_per_unit]
            else:raise ValueError('view must be front or left')
            errors.extend((np.asarray(uv)-o['pixel'])*float(o.get('weight',1)))
        errors.extend(delta*np.sqrt(regularization)*pixels_per_unit)
        return errors
    fit=least_squares(residual,np.zeros(base.size),max_nfev=60)
    delta=fit.x.reshape(-1,3)
    for ident,d in zip(ids,delta):
        p=parts[ident]
        if p['kind']=='ellipsoid':p['center']=(np.asarray(p['center'])+d).tolist()
        else:
            for q in p['points']:q[:3]=(np.asarray(q[:3])+d).tolist()
    return doc,{'rms_pixel_error':float(np.linalg.norm(residual(fit.x)[:2*len(observations)])/max(1,len(observations))**.5),
                'moved_parts':ids,'views':list({o.get('view','front') for o in observations})}
