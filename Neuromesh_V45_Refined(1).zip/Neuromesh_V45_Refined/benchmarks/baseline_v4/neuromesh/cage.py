"""Connected anatomical control cages, Catmull–Clark surfaces, and sculpt layers.
No species logic: designs supply sections, patch attachments and landmarks.
"""
import copy, json, time
from pathlib import Path
import numpy as np
import trimesh
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import dijkstra
from .doctor import diagnose


def resolve_section(q, doc):
    if isinstance(q,dict):
        if 'joint' in q:
            joints=doc.get('skeleton',{}).get('joints',{})
            if q['joint'] not in joints:raise ValueError('Unknown anatomical joint')
            return list(joints[q['joint']])+list(q['radii'])
        return list(q['center'])+list(q['radii'])
    return q


def validate_cage(doc):
    if doc.get('ngl_version') != 2: raise ValueError('Cages use ngl_version: 2')
    cage=doc.get('cage',{})
    if len(cage.get('sections',[]))<3: raise ValueError('At least three trunk sections required')
    ids=set()
    records=cage['sections']+cage.get('branches',[])
    for q in records:
        if not q.get('id') or q['id'] in ids: raise ValueError('Unique cage IDs required')
        ids.add(q['id'])
    for q in cage['sections']:
        a=np.asarray(q.get('center',[]),float);r=np.asarray(q.get('radii',[]),float)
        if a.shape!=(3,) or r.shape!=(2,) or not np.isfinite(np.r_[a,r]).all() or min(r)<=0: raise ValueError('Invalid section')
    for b in cage.get('branches',[]):
        if len(b.get('sections',[]))<2: raise ValueError('Branch requires two sections')
        for q in b['sections']:
            a=np.asarray(resolve_section(q,doc),float)
            if a.shape!=(5,) or not np.isfinite(a).all() or min(a[3:])<=0: raise ValueError('Branch [x,y,z,r1,r2] required')
    return doc


def compile_cage(doc):
    validate_cage(doc);cage=doc['cage'];n=int(cage.get('ring_vertices',8))
    if n<8 or n>32 or n%4: raise ValueError('ring_vertices: multiples of 4, 8–32')
    vertices=[];faces={};labels={};theta=np.arange(n)*2*np.pi/n
    centers=np.asarray([q['center'] for q in cage['sections']]);tangents=np.gradient(centers,axis=0)
    tangents/=np.maximum(np.linalg.norm(tangents,axis=1)[:,None],1e-10)
    frame_u=np.array([1.,0.,0.]);frames=[]
    for tangent in tangents:
        frame_u-=np.dot(frame_u,tangent)*tangent
        if np.linalg.norm(frame_u)<1e-6:raise ValueError('Trunk doubles back too sharply')
        frame_u/=np.linalg.norm(frame_u);frames.append((frame_u.copy(),np.cross(frame_u,tangent)))
    for qi,q in enumerate(cage['sections']):
        # Trunk sections in XZ planes; arbitrary angular radial factors control silhouette.
        c=np.asarray(q['center']);r=q['radii'];rad=np.asarray(q.get('radial',[1]*n),float)
        if rad.shape!=(n,) or min(rad)<=0:raise ValueError('Positive radial factors matching ring size required')
        u,v=frames[qi]
        ring=(r[0]*np.cos(theta)*rad)[:,None]*u+(r[1]*np.sin(theta)*rad)[:,None]*v+c
        offsets=np.asarray(q.get('offsets',np.zeros((n,3))),float)
        if offsets.shape!=(n,3) or not np.isfinite(offsets).all():raise ValueError('Offsets require one XYZ per ring vertex')
        ring+=offsets
        labels[q['id']]=list(range(len(vertices),len(vertices)+n));vertices.extend(ring)
    sections=cage['sections']
    for j in range(len(sections)-1):
        for k in range(n):faces[f"{sections[j]['id']}:{k}"]=[j*n+k,(j+1)*n+k,(j+1)*n+(k+1)%n,j*n+(k+1)%n]
    faces['front_cap']=list(range(n));faces['rear_cap']=list(range((len(sections)-1)*n,len(sections)*n))[::-1]
    for b in cage.get('branches',[]):
        parent=b['attach']
        if parent.endswith(':auto'):
            prefix=parent[:-4];target=np.asarray(resolve_section(b['sections'][0],doc)[:3])
            candidates=[key for key in faces if key.startswith(prefix)]
            def score(key):
                pts=np.asarray(vertices)[faces[key]];normal=np.cross(pts[1]-pts[0],pts[2]-pts[0]);normal/=max(np.linalg.norm(normal),1e-10)
                return np.dot(target-pts.mean(0),normal)
            if not candidates:raise ValueError('No attachment patches available')
            parent=max(candidates,key=score)
        if ':strip:' in parent and parent not in faces:
            source=parent.rsplit(':strip:',1)[0]
            if source not in faces or len(faces[source])!=4:raise ValueError('Strip needs available quad patch')
            a,b0,c,d=faces.pop(source);rows=[]
            for start,end in [(a,b0),(d,c)]:
                row=[start]
                for k in range(1,4):row.append(len(vertices));vertices.append(np.asarray(vertices[start])*(1-k/4)+np.asarray(vertices[end])*k/4)
                row.append(end);rows.append(row)
                for key,face in list(faces.items()):
                    new=[]
                    for i,x in enumerate(face):
                        y=face[(i+1)%len(face)];new.append(x)
                        if x==start and y==end:new.extend(row[1:-1])
                        elif x==end and y==start:new.extend(row[-2:0:-1])
                    faces[key]=new
            for k in range(4):faces[source+':strip:'+str(k)]=[rows[0][k],rows[0][k+1],rows[1][k+1],rows[1][k]]
        if parent not in faces:raise ValueError(f'Unavailable surface patch: {parent}')
        loop=faces.pop(parent);labels[b['id']]=[];last=np.asarray(vertices)[loop].mean(0)
        controls=[resolve_section(q,doc) for q in b['sections']]
        if b.get('relative'):
            controls=[list(np.asarray(q[:3])+last)+list(q[3:]) for q in controls]
        direction=np.asarray(controls[0][:3])-last
        if np.linalg.norm(direction)<1e-8:raise ValueError('Branch center coincides with root')
        direction/=np.linalg.norm(direction)
        u=np.asarray(vertices[loop[0]])-last;u-=u.dot(direction)*direction
        if np.linalg.norm(u)<1e-8:u=np.eye(3)[np.argmin(abs(direction))];u-=u.dot(direction)*direction
        u/=np.linalg.norm(u)
        count=len(loop)
        for j,q in enumerate(controls):
            c=np.asarray(q[:3]);d=c-last;d/=max(np.linalg.norm(d),1e-10)
            u-=u.dot(d)*d
            if np.linalg.norm(u)<1e-6:raise ValueError('Branch folds too sharply')
            u/=np.linalg.norm(u);v=np.cross(d,u)
            angles=np.arange(count)*2*np.pi/count
            ring=c+np.cos(angles)[:,None]*u*q[3]+np.sin(angles)[:,None]*v*q[4]
            nxt=list(range(len(vertices),len(vertices)+count));vertices.extend(ring);labels[b['id']].extend(nxt)
            for k in range(count):faces[f"{b['id']}:{j}:{k}"]=[loop[k],loop[(k+1)%count],nxt[(k+1)%count],nxt[k]]
            loop=nxt;last=c
        faces[b['id']+':cap']=loop
    return np.asarray(vertices,float),list(faces.values()),labels


def subdivide(vertices, faces):
    """Closed manifold Catmull–Clark, shared edge and face vertices, any face valence."""
    edge_map={};edges=[];adj=[];vf=[[] for _ in vertices];ve=[[] for _ in vertices]
    fp=np.array([vertices[f].mean(0) for f in faces])
    for fi,f in enumerate(faces):
        for i,a in enumerate(f):
            vf[a].append(fi);b=f[(i+1)%len(f)];key=tuple(sorted((a,b)))
            if key not in edge_map:
                ei=len(edges);edge_map[key]=ei;edges.append(key);adj.append([]);ve[a].append(ei);ve[b].append(ei)
            adj[edge_map[key]].append(fi)
    if any(len(a)!=2 for a in adj):raise ValueError('Cage must be closed and manifold')
    edges=np.asarray(edges,int);ep=(vertices[edges].sum(1)+np.array([fp[a].sum(0) for a in adj]))/4
    updated=np.empty_like(vertices)
    for i,p in enumerate(vertices):
        n=len(ve[i]);F=fp[vf[i]].mean(0);R=vertices[edges[ve[i]]].mean((0,1));updated[i]=(F+2*R+(n-3)*p)/n
    nv=len(vertices);ne=len(edges);result=np.vstack([updated,ep,fp]);quads=[]
    for fi,f in enumerate(faces):
        for k,a in enumerate(f):quads.append([a,nv+edge_map[tuple(sorted((a,f[(k+1)%len(f)])))],nv+ne+fi,nv+edge_map[tuple(sorted((f[k-1],a)))]] )
    return result,quads


def triangulate(v, faces):
    triangles=[]
    for f in faces:
        for k in range(1,len(f)-1):triangles.append([f[0],f[k],f[k+1]])
    m=trimesh.Trimesh(v,np.asarray(triangles),process=False)
    if not m.is_winding_consistent or m.volume<0:trimesh.repair.fix_normals(m)
    return m


def local_subdivide(mesh, center, radius, max_faces=250000):
    """Conforming regional edge refinement. Neighbors split shared edges too.
    Adds resolution without changing the existing piecewise linear surface.
    """
    v=mesh.vertices;f=mesh.faces;inside=np.linalg.norm(mesh.triangles_center-center,axis=1)<radius
    selected={tuple(sorted(e)) for t in f[inside] for e in [(t[0],t[1]),(t[1],t[2]),(t[2],t[0])]}
    if len(f)+4*len(selected)>max_faces:raise MemoryError('Regional subdivision exceeds face budget')
    new=list(v);mid={}
    for a,b in sorted(selected):mid[(a,b)]=len(new);new.append((v[a]+v[b])/2)
    triangles=[]
    for a,b,c in f:
        ab=mid.get(tuple(sorted((a,b))));bc=mid.get(tuple(sorted((b,c))));ca=mid.get(tuple(sorted((c,a))))
        hits=sum(x is not None for x in (ab,bc,ca))
        if hits==0:triangles.append([a,b,c])
        elif hits==3:triangles.extend([[a,ab,ca],[ab,b,bc],[ca,bc,c],[ab,bc,ca]])
        elif hits==1:
            if ab is not None:triangles.extend([[a,ab,c],[ab,b,c]])
            elif bc is not None:triangles.extend([[b,bc,a],[bc,c,a]])
            else:triangles.extend([[c,ca,b],[ca,a,b]])
        else:
            if ab is None:a,b,c=c,a,b;ab,bc,ca=ca,ab,bc
            elif ca is None:a,b,c=b,c,a;ab,bc,ca=bc,ca,ab
            triangles.extend([[a,ab,ca],[ab,b,c],[ab,c,ca]])
    return trimesh.Trimesh(np.asarray(new),triangles,process=False)


def sculpt(mesh, stroke, max_faces):
    op=stroke['op'];center=np.asarray(stroke['center'],float);radius=float(stroke['radius']);strength=float(stroke.get('strength',.03))
    if op not in ('grab','clay','crease','flatten','smooth','pinch','inflate','carve') or radius<=0:raise ValueError('Invalid surface brush')
    if stroke.get('subdivide'):mesh=local_subdivide(mesh,center,radius,max_faces)
    v=mesh.vertices.copy();dist=np.linalg.norm(v-center,axis=1)
    if stroke.get('geodesic',True):
        edges=mesh.edges_unique;length=np.linalg.norm(v[edges[:,0]]-v[edges[:,1]],axis=1)
        graph=coo_matrix((np.r_[length,length],(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(len(v),len(v))).tocsr()
        nearest=int(np.argmin(dist));offset=float(dist[nearest])
        dist=dijkstra(graph,indices=nearest,directed=False,limit=radius)+offset
    w=np.maximum(1-dist/radius,0)**2;normal=np.asarray(mesh.vertex_normals)
    axis=np.asarray(stroke.get('normal',[0,0,1]),float);axis/=max(np.linalg.norm(axis),1e-10)
    delta=np.zeros_like(v)
    if op=='grab':delta=w[:,None]*np.asarray(stroke['vector'])
    elif op in ('inflate','carve'):delta=w[:,None]*normal*strength*(-1 if op=='carve' else 1)
    elif op=='clay':
        if 'normal' not in stroke:
            axis=(normal*w[:,None]).sum(0);axis/=max(np.linalg.norm(axis),1e-10)
        deposit=np.clip(strength-(v-center)@axis,0,max(strength,0))
        delta=(w*deposit)[:,None]*axis
    elif op=='flatten':delta=-w[:,None]*np.clip(strength,0,1)*((v-center)@axis)[:,None]*axis
    elif op=='pinch':
        rel=v-center;rel-=np.outer(rel@axis,axis);delta=-rel*w[:,None]*strength
    elif op=='crease':
        width=float(stroke.get('width',radius*.16));plane=(v-center)@axis
        delta=-normal*(strength*w*np.exp(-(plane/max(width,1e-8))**2))[:,None]
    else:
        edges=mesh.edges_unique;total=np.zeros_like(v);counts=np.zeros(len(v))
        np.add.at(total,edges[:,0],v[edges[:,1]]);np.add.at(total,edges[:,1],v[edges[:,0]])
        np.add.at(counts,edges.ravel(),1);delta=(total/np.maximum(counts[:,None],1)-v)*w[:,None]*np.clip(strength,0,1)
    # Reject local foldovers; this is not a general intersection certificate.
    before=mesh.face_normals.copy();scale=1.
    for attempt in range(8):
        result=trimesh.Trimesh(v+delta*scale,mesh.faces,process=False)
        if np.all(result.area_faces>1e-12) and np.all(np.sum(result.face_normals*before,axis=1)>.05):return result,scale
        scale*=.5
    raise ValueError('Sculpt creates inverted/degenerate faces; reduce strength')


def build_cage(engine,doc):
    from .engine import digest
    tic=time.monotonic();v,faces,labels=compile_cage(doc);settings=doc.get('settings',{})
    level=int(settings.get('subdivision',{'draft':1,'medium':2,'high':3}.get(settings.get('detail','medium'),2)))
    budget=int(settings.get('max_faces',200000));memory=float(settings.get('max_memory_mb',512))
    if level<0 or level>5:raise ValueError('Subdivision 0–5')
    estimate=sum(len(f) for f in faces)*4**max(level-1,0)*2
    if estimate>budget or estimate*.004>memory:raise MemoryError('Subdivision exceeds face or working memory budget')
    cachekey=digest(['cage4b',doc['cage'],doc.get('skeleton',{}),level]);cache=engine.cache/(cachekey+'.npz');hit=cache.exists()
    if hit:
        data=np.load(cache);mesh=trimesh.Trimesh(data['v'],data['f'],process=False)
    else:
        for _ in range(level):v,faces=subdivide(v,faces)
        mesh=triangulate(v,faces);np.savez_compressed(cache,v=mesh.vertices,f=mesh.faces)
    strokes=[]
    for stroke in doc.get('surface_strokes',[]):mesh,scale=sculpt(mesh,stroke,budget);strokes.append({'op':stroke['op'],'accepted_scale':scale})
    if len(mesh.faces)>budget:raise MemoryError('Face budget exceeded')
    integrity=diagnose(mesh)
    if not integrity['watertight'] or integrity['nonmanifold_edges'] or integrity['degenerate_faces'] or not integrity['consistent_winding']:raise RuntimeError('Invalid generated surface')
    from .validation import crossing_report
    integrity['triangle_crossings']=crossing_report(mesh)
    if integrity['triangle_crossings'].get('crossing_pairs',0)>0:raise ValueError('Surface intersects itself; revise controls or stroke')
    if integrity['triangle_crossings']['status']!='measured':raise MemoryError('Intersection verification budget exceeded')
    mesh.visual.vertex_colors=np.tile([174,177,180,255],(len(mesh.vertices),1))
    out=engine.root/'build';out.mkdir(exist_ok=True);scene=trimesh.Scene();scene.add_geometry(mesh,geom_name='flesh')
    (out/'model.glb').write_bytes(scene.export(file_type='glb'));(out/'model.obj').write_text(mesh.export(file_type='obj'));(out/'model.mtl').write_text('newmtl flesh\nKd 0.68 0.69 0.70\n')
    v0,f0,l0=compile_cage(doc);(out/'control_cage.json').write_text(json.dumps({'vertices':v0.tolist(),'faces':f0,'landmark_vertices':l0},indent=2))
    cachefiles=sorted(engine.cache.glob('*.npz'),key=lambda p:p.stat().st_mtime);cachebytes=sum(p.stat().st_size for p in cachefiles)
    for p in cachefiles:
        if cachebytes<=float(settings.get('max_cache_mb',64))*1024**2:break
        cachebytes-=p.stat().st_size;p.unlink()
    report={'version':digest(doc),'kernel':'connected control cage + Catmull-Clark','subdivision':level,'control_vertices':len(v0),'control_faces':len(f0),'cage_cache_hit':hit,'seconds':round(time.monotonic()-tic,3),'total_triangles':len(mesh.faces),'groups':{'flesh':integrity},'strokes':strokes,'estimated_working_mb':round(estimate*.004,2),'files':['model.glb','model.obj','control_cage.json']}
    (out/'report.json').write_text(json.dumps(report,indent=2));return report
