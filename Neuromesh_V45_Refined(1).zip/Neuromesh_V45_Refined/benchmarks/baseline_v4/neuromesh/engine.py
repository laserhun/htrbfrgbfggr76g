"""Neuromesh Omega: deterministic CPU implicit geometry from named NGL parts."""
from __future__ import annotations
import copy, hashlib, json, math, os, time
from pathlib import Path
import numpy as np
from skimage.measure import marching_cubes
import trimesh
from .kernel import loft_field, loft_bounds

SCHEMA = 1
GROUPS={'flesh','eye_white','iris','pupil','detail','inner_ear','nose','stripe','whisker','face_skin','muzzle','belly','claw','lip'}
KINDS = {'ellipsoid', 'sweep', 'profile_sweep', 'anatomy_sweep', 'loft'}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()[:20]


def validate_ngl(doc):
    if doc.get('ngl_version') == 2:
        from .cage import validate_cage
        return validate_cage(doc)
    if doc.get('ngl_version') != SCHEMA or not isinstance(doc.get('parts'), list):
        raise ValueError('NGL requires ngl_version: 1 and a parts list')
    ids = set()
    for p in doc['parts']:
        ident = p.get('id')
        if not isinstance(ident, str) or not ident or ident in ids:
            raise ValueError('Each part needs a unique nonempty id')
        ids.add(ident)
        if p.get('role','solid') not in ('solid','cut','paint'): raise ValueError('role must be solid, cut, or paint')
        if p.get('stage','primary') not in ('primary','secondary','detail'): raise ValueError('unknown modeling stage')
        if p.get('kind') not in KINDS:
            raise ValueError(f'{ident}: unknown kind; use ellipsoid, sweep, profile_sweep, anatomy_sweep or loft')
        if p['kind'] == 'ellipsoid':
            if len(p.get('center', [])) != 3 or len(p.get('radii', [])) != 3 or min(p['radii']) <= 0:
                raise ValueError(f'{ident}: invalid center or radii')
        else:
            points = p.get('points', [])
            expected=5 if p['kind'] in ('profile_sweep','anatomy_sweep','loft') else 4
            if len(points) < 2 or any(len(q) != expected or min(q[3:]) <= 0 for q in points):
                raise ValueError(f'{ident}: points require [x,y,z,r] or [x,y,z,rx,ry]')
            if p['kind']=='profile_sweep' and any(b[2]<=a[2] for a,b in zip(points[:-1],points[1:])):
                raise ValueError(f'{ident}: profile_sweep heights must increase')
        if p.get('group', 'flesh') not in GROUPS:
            raise ValueError(f'{ident}: unknown group')
        if float(p.get('blend', .1)) < 0 or float(p.get('roughness', 0)) < 0:
            raise ValueError(f'{ident}: negative blend or roughness')
    return doc


def bounds(p):
    if p['kind']=='loft': return loft_bounds(p)
    if p['kind'] == 'ellipsoid':
        c, r = np.array(p['center']), np.array(p['radii'])
        return c-r, c+r
    q = np.asarray(p['points'], dtype=float)
    if p['kind']=='anatomy_sweep':
        q=np.asarray(p['points'],dtype=float);r=np.max(q[:,3:5],axis=1)
        return np.min(q[:,:3]-r[:,None],axis=0),np.max(q[:,:3]+r[:,None],axis=0)
    if p['kind']=='profile_sweep':
        return np.min(q[:,:3]-np.column_stack([q[:,3],q[:,4],np.zeros(len(q))]),axis=0), np.max(q[:,:3]+np.column_stack([q[:,3],q[:,4],np.zeros(len(q))]),axis=0)
    return np.min(q[:,:3]-q[:,3,None], axis=0), np.max(q[:,:3]+q[:,3,None], axis=0)


def compile_skeleton(doc):
    """Compile named joint/bone records into anisotropic implicit bone sweeps."""
    doc=copy.deepcopy(doc)
    if doc.get('ngl_version') == 2: return doc
    doc['parts']=[p for p in doc['parts'] if not p.get('_skeleton_generated')]
    sk=doc.get('skeleton',{});joints=sk.get('joints',{})
    for bone in sk.get('bones',[]):
        start=joints[bone['start']];end=joints[bone['end']]
        r0=bone.get('radii_start',[bone.get('radius',.1)]*2);r1=bone.get('radii_end',r0)
        doc['parts'].append({'id':'bone_'+bone['id'],'kind':'loft' if doc.get('settings',{}).get('continuous_bones') else 'anatomy_sweep',
            'points':[list(start)+list(r0),list(end)+list(r1)],
            'group':bone.get('group','flesh'),'blend':bone.get('blend',.08),'_skeleton_generated':True})
    return doc


def field(p, xyz):
    if p['kind'] == 'loft':
        d = loft_field(p, xyz)
    elif p['kind'] == 'ellipsoid':
        r = np.asarray(p['radii'], dtype=np.float32)
        v = xyz - np.asarray(p['center'], dtype=np.float32)
        k0 = np.linalg.norm(v/r, axis=-1)
        k1 = np.linalg.norm(v/(r*r), axis=-1)
        d = np.where(k0 < 1e-6, -float(np.min(r)), k0*(k0-1)/(k1+1e-8))
    elif p['kind']=='anatomy_sweep':
        pts=np.asarray(p['points'],dtype=np.float32);d=np.full(xyz.shape[:-1],np.inf,dtype=np.float32)
        for a,b in zip(pts[:-1],pts[1:]):
            delta=b[:3]-a[:3];length=np.linalg.norm(delta);tangent=delta/(length+1e-9)
            reference=np.array([0,0,1],dtype=np.float32) if abs(tangent[2])<.92 else np.array([0,1,0],dtype=np.float32)
            u=np.cross(tangent,reference);u/=np.linalg.norm(u)+1e-9;v=np.cross(tangent,u)
            rel=xyz-a[:3];along=np.sum(rel*tangent,axis=-1);clamped=np.clip(along,0,length)
            radial=rel-clamped[...,None]*tangent
            ru=a[3]+np.clip(along/max(length,1e-9),0,1)*(b[3]-a[3]);rv=a[4]+np.clip(along/max(length,1e-9),0,1)*(b[4]-a[4])
            rho=np.sqrt((np.sum(radial*u,axis=-1)/(ru+1e-8))**2+(np.sum(radial*v,axis=-1)/(rv+1e-8))**2)
            side=(rho-1)*np.minimum(ru,rv);cap=np.maximum(-along,along-length)
            sd=np.sqrt(np.maximum(side,0)**2+np.maximum(cap,0)**2)+np.minimum(np.maximum(side,cap),0)
            d=np.minimum(d,sd)
    elif p['kind']=='profile_sweep':
        pts=np.asarray(p['points'],dtype=np.float32)
        z=xyz[...,2]
        cx=np.interp(z,pts[:,2],pts[:,0]);cy=np.interp(z,pts[:,2],pts[:,1])
        rx=np.interp(z,pts[:,2],pts[:,3]);ry=np.interp(z,pts[:,2],pts[:,4])
        dxy=(np.sqrt(((xyz[...,0]-cx)/rx)**2+((xyz[...,1]-cy)/ry)**2)-1)*np.minimum(rx,ry)
        dz=np.maximum(pts[0,2]-z,z-pts[-1,2])
        d=np.sqrt(np.maximum(dxy,0)**2+np.maximum(dz,0)**2)+np.minimum(np.maximum(dxy,dz),0)
    else:
        pts = np.asarray(p['points'], dtype=np.float32)
        d = np.full(xyz.shape[:-1], np.inf, dtype=np.float32)
        # Piecewise conical capsules. Segment spheres blend continuously at joints.
        for a,b in zip(pts[:-1], pts[1:]):
            ab = b[:3]-a[:3]
            t = np.clip(np.sum((xyz-a[:3])*ab, axis=-1)/(np.dot(ab,ab)+1e-8), 0, 1)
            v = xyz-(a[:3]+t[...,None]*ab)
            sd = np.linalg.norm(v, axis=-1)-(a[3]+t*(b[3]-a[3]))
            d = np.minimum(d, sd)
    rough = float(p.get('roughness',0))
    if rough:
        freq = float(p.get('frequency', 11))
        x,y,z = xyz[...,0]*freq, xyz[...,1]*freq, xyz[...,2]*freq
        phase = int(digest(p['id'])[:5],16)*.0001
        noise = np.sin(x+1.7*np.sin(z*.77+phase))*np.sin(y*.83+np.cos(x*.61))
        noise += .4*np.sin(2.37*z+2.11*y+phase)*np.sin(2.07*x-y)
        d = d + rough*noise
    return d.astype(np.float32)


def smooth_union(a,b,k):
    if k <= 0: return np.minimum(a,b)
    h = np.maximum(k-np.abs(a-b),0)/k
    return np.minimum(a,b)-h*h*k*.25


class Engine:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.cache = self.root/'cache'
        self.cache.mkdir(exist_ok=True)
        self.project_file = self.root/'model.ngl.json'
        self.versions = self.root/'versions'
        self.versions.mkdir(exist_ok=True)

    def load(self):
        return validate_ngl(json.loads(self.project_file.read_text()))

    def save(self, doc):
        validate_ngl(doc)
        if self.project_file.exists():
            old = json.loads(self.project_file.read_text())
            oldhash = digest(old)
            (self.versions/f'{oldhash}.ngl.json').write_text(json.dumps(old,indent=2))
        self.project_file.write_text(json.dumps(doc, indent=2))
        return digest(doc)

    def generate(self, doc, detail=None):
        doc = compile_skeleton(copy.deepcopy(doc))
        validate_ngl(doc)
        if detail is not None: doc.setdefault('settings',{})['detail'] = detail
        if doc.get('ngl_version')==2:
            report=self.build(doc)
            self.save(doc)
            return report
        self.save(doc)
        return self.build(doc)

    def modify(self, edits, detail=None):
        doc = self.load()
        if doc.get('ngl_version') == 2:
            from .cage_edit import apply_edits
            return self.generate(apply_edits(doc, edits),detail)
        for edit in edits:
            op, ident = edit.get('op'), edit.get('id')
            if op == 'update_settings':
                doc.setdefault('settings',{}).update(edit['changes'])
                continue
            if op == 'update_joint':
                if ident not in doc.get('skeleton',{}).get('joints',{}): raise ValueError('unknown joint')
                doc['skeleton']['joints'][ident] = edit['position']
                continue
            matching = [i for i,p in enumerate(doc['parts']) if p['id'] == ident]
            if op == 'add':
                if matching: raise ValueError(f'part already exists: {ident}')
                doc['parts'].append(edit['part'])
            elif not matching: raise ValueError(f'unknown part: {ident}')
            elif op == 'remove': doc['parts'].pop(matching[0])
            elif op == 'update': doc['parts'][matching[0]].update(edit['changes'])
            else: raise ValueError(f'unknown edit operation: {op}')
        return self.generate(doc, detail)

    def rollback(self, version):
        path = self.versions/f'{version}.ngl.json'
        if not path.exists(): raise ValueError(f'unknown version: {version}')
        return self.generate(json.loads(path.read_text()))

    def build(self, doc=None):
        doc = self.load() if doc is None else validate_ngl(doc)
        if doc.get('ngl_version') == 2:
            from .cage import build_cage
            return build_cage(self,doc)
        tic = time.monotonic()
        settings = doc.get('settings',{})
        detail = settings.get('detail','medium')
        step = {'draft':.105, 'medium':.065, 'high':.042}.get(detail)
        if step is None: raise ValueError('detail must be draft, medium, or high')
        step = float(settings.get('voxel',step))
        if not .015 <= step <= .3: raise ValueError('voxel outside safe range .015–.3')
        side = int(settings.get('brick',24))
        if not 12 <= side <= 48: raise ValueError('brick outside 12–48')
        stages={'primary':0,'secondary':1,'detail':2}
        stage=settings.get('max_stage','detail')
        if stage not in stages: raise ValueError('max_stage must be primary, secondary, detail')
        parts=[p for p in doc['parts'] if stages[p.get('stage','primary')]<=stages[stage]]
        paint=[p for p in parts if p.get('role')=='paint']
        parts=[p for p in parts if p.get('role')!='paint']
        skeleton=doc.get('skeleton',{})
        joints=skeleton.get('joints',{})
        for bone in skeleton.get('bones',[]):
            if bone.get('start') not in joints or bone.get('end') not in joints: raise ValueError('Skeleton bones must reference named joints')
        modifiers=doc.get('modifiers',[])
        for mod in modifiers:
            if mod.get('op') not in ('grab','inflate','clay','carve','crease','smooth') or len(mod.get('center',[]))!=3 or float(mod.get('radius',0))<=0:
                raise ValueError('Invalid sculpt modifier')
        if not parts: raise ValueError('No parts')
        solids=[p for p in parts if p.get('role','solid')=='solid']
        if not solids: raise ValueError('No additive volumes')
        bb=np.array([bounds(p) for p in solids])
        pad=max(.15, max(float(p.get('blend',.1)) for p in parts)+.1)
        tile=side*step
        lo=np.floor((bb[:,0,:].min(axis=0)-pad)/tile)*tile
        hi=np.ceil((bb[:,1,:].max(axis=0)+pad)/tile)*tile
        shape=np.ceil((hi-lo)/step).astype(int)
        max_cells=int(settings.get('max_cells',8_000_000))
        if np.prod(shape)>max_cells:
            raise MemoryError(f'Grid {shape.tolist()} requires {int(np.prod(shape)):,} cells; use draft or increase voxel')
        groups={g:[] for g in GROUPS}
        for p in parts: groups[p.get('group','flesh')].append(p)
        halo=max([0]+[int(math.ceil(3*float(m.get('sigma',1)))) for m in modifiers if m['op']=='smooth'])
        if halo>16: raise ValueError('smooth sigma too large for brick halo')
        memory_mb=float(settings.get('max_memory_mb',512))
        brick_mb=(side+2*halo+1)**3*180/1024**2
        grid_workspace_mb=float(np.prod(shape+1))*24/1024**2
        if brick_mb+grid_workspace_mb>memory_mb: raise MemoryError('Grid and brick working-memory estimate exceeds max_memory_mb')
        meshes={}; cache_hits=0; sampled=0; active=0
        bricks=[(i,j,k) for i in range(0,shape[0],side) for j in range(0,shape[1],side) for k in range(0,shape[2],side)]
        base_step=step;group_grids={};total_cells=0;total_bricks=0;adjusted_parts=[]
        for group,group_parts in groups.items():
            if not group_parts: continue
            step=float(settings.get('group_voxel',{}).get(group,base_step))
            if not .008<=step<=.3: raise ValueError('group_voxel outside .008–.3')
            group_parts=copy.deepcopy(group_parts)
            floor=float(settings.get('min_feature_voxels',0))*step
            for part in group_parts:
                if part.get('role','solid')!='solid' or floor<=0: continue
                changed=False
                if part['kind']=='ellipsoid':
                    before=part['radii'];part['radii']=[max(float(r),floor) for r in before]
                    changed=part['radii']!=before
                else:
                    for point in part['points']:
                        for j in range(3,len(point)):
                            if point[j]<floor: point[j]=floor;changed=True
                if changed: adjusted_parts.append(part['id'])
            group_solids=[p for p in group_parts if p.get('role','solid')=='solid']
            if not group_solids: continue
            bb=np.array([bounds(p) for p in group_solids]);tile=side*step
            lo=np.floor((bb[:,0,:].min(0)-pad)/tile)*tile
            hi=np.ceil((bb[:,1,:].max(0)+pad)/tile)*tile
            shape=np.ceil((hi-lo)/step).astype(int)
            if np.prod(shape)>max_cells: raise MemoryError('Group grid exceeds max_cells')
            grid_workspace_mb=float(np.prod(shape+1))*24/1024**2
            resident_mesh_mb=sum(len(m.vertices)*80 for m in meshes.values())/1024**2
            if brick_mb+grid_workspace_mb+resident_mesh_mb>memory_mb: raise MemoryError('Group working estimate exceeds max_memory_mb')
            bricks=[(i,j,k) for i in range(0,shape[0],side) for j in range(0,shape[1],side) for k in range(0,shape[2],side)]
            group_grids[group]={'voxel':step,'cells':int(np.prod(shape)),'estimated_grid_workspace_mb':round(grid_workspace_mb,2)}
            total_cells+=int(np.prod(shape));total_bricks+=len(bricks)
            volume=np.full(tuple(shape+1),max(1.,tile),dtype='f4')
            for origin in bricks:
                end=np.minimum(np.array(origin)+side,shape)
                low=lo+np.array(origin)*step
                high=lo+end*step
                candidates=[]
                for p in group_parts:
                    pl,ph=bounds(p)
                    reach=max(.28,float(p.get('blend', .1))*2)+float(p.get('roughness',0))*1.4+step*(2+halo)
                    if np.all(ph+reach>=low) and np.all(pl-reach<=high): candidates.append(p)
                if not candidates: continue
                arrays=[np.arange(origin[q]-halo,end[q]+1+halo,dtype=np.float32)*step+lo[q] for q in range(3)]
                xyz=np.stack(np.meshgrid(*arrays,indexing='ij'),-1)
                combined=None; cutters=[]
                for p in candidates:
                    grab=[m for m in modifiers if m['op']=='grab' and m.get('group','flesh')==group and np.linalg.norm(np.asarray(m['center'])-(low+high)*.5)<float(m['radius'])+np.linalg.norm(high-low)*.5]
                    key=digest(['v35',halo,p,list(map(int,origin)),end.astype(int).tolist(),round(step,7),np.round(lo,7).tolist(),grab])
                    path=self.cache/f'{key}.npy'
                    if path.exists():
                        val=np.load(path); cache_hits+=1
                    else:
                        sample_xyz=xyz
                        for gm in grab:
                            dist=np.linalg.norm(sample_xyz-np.asarray(gm['center']),axis=-1)
                            weight=np.maximum(1-dist/float(gm['radius']),0)**2
                            sample_xyz=sample_xyz-weight[...,None]*np.asarray(gm.get('vector',[0,0,0]))
                        val=field(p,sample_xyz); np.save(path,val); sampled+=1
                    if p.get('role')=='cut': cutters.append((p,val))
                    else: combined=val if combined is None else smooth_union(combined,val,float(p.get('blend',0)))
                if combined is None: continue
                for cutter,val in cutters:
                    combined=-smooth_union(-combined,val,float(cutter.get('blend',0)))
                for mod in modifiers:
                    if mod.get('group','flesh')!=group or mod['op']=='grab':continue
                    radius=float(mod['radius']);dist=np.linalg.norm(xyz-np.asarray(mod['center']),axis=-1)
                    influence=np.maximum(1-dist/radius,0)**2
                    strength=float(mod.get('strength',.05))
                    if mod['op'] in ('inflate','clay'):combined=combined-strength*influence
                    elif mod['op']=='carve':combined=combined+strength*influence
                    elif mod['op']=='crease':
                        axis=np.asarray(mod.get('normal',[0,0,1]),dtype=float);axis/=max(np.linalg.norm(axis),1e-8)
                        plane=np.abs(np.sum((xyz-np.asarray(mod['center']))*axis,axis=-1))
                        combined=combined+strength*influence*np.exp(-plane**2/(step*2)**2)
                    elif mod['op']=='smooth':
                        from scipy.ndimage import gaussian_filter
                        sigma=max(.1,float(mod.get('sigma',1.)) )
                        combined=combined*(1-influence)+gaussian_filter(combined,sigma=sigma)*influence
                if halo: combined=combined[halo:-halo,halo:-halo,halo:-halo]
                sl=tuple(slice(origin[q],int(end[q])+1) for q in range(3))
                volume[sl]=combined
                if combined.min()<=0 and combined.max()>=0: active+=1
            if volume.min()<0:
                v,f,_,_=marching_cubes(volume,level=0,spacing=(step,step,step),allow_degenerate=False)
                mesh=trimesh.Trimesh(vertices=v.astype('f8')+lo,faces=f,process=False)
                mesh.remove_unreferenced_vertices()
                if len(mesh.vertices)*80/1024**2+grid_workspace_mb+brick_mb>memory_mb: raise MemoryError('Mesh working estimate exceeds max_memory_mb')
                meshes[group]=mesh

        if not meshes: raise RuntimeError('No zero surface extracted; inspect NGL bounds')
        out=self.root/'build'; out.mkdir(exist_ok=True)
        scene=trimesh.Scene()
        colors={'flesh':[115,47,55,255],'eye_white':[222,208,184,255], 'iris':[183,175,45,255], 'pupil':[21,17,18,255], 'detail':[170,92,95,255],'inner_ear':[167,111,119,255],'nose':[147,88,94,255],'stripe':[70,71,77,255],'whisker':[225,220,207,255],'face_skin':[145,56,68,255],'muzzle':[173,95,67,255],'belly':[164,111,70,255],'claw':[49,38,35,255],'lip':[62,38,38,255]}
        colors.update({g:list(c) if len(c)==4 else list(c)+[255] for g,c in settings.get('colors',{}).items() if g in colors})
        for g,m in meshes.items():
            vertex_colors=np.tile(colors[g],(len(m.vertices),1)).astype(float)
            for region in paint:
                if region.get('group','flesh')!=g: continue
                distance=field(region,m.vertices.astype('f4'))
                falloff=max(float(region.get('falloff',.04)),1e-5)
                weight=np.clip(-distance/falloff,0,1)[:,None]
                color=np.asarray(region.get('color',colors[g][:3])[:3])
                vertex_colors[:,:3]=vertex_colors[:,:3]*(1-weight)+color*weight
            m.visual.vertex_colors=vertex_colors.astype('u1')
            scene.add_geometry(m,geom_name=g)
        (out/'model.glb').write_bytes(scene.export(file_type='glb'))
        # OBJ grouping, and MTL with material colors; OBJ supports editing in Blender.
        with (out/'model.obj').open('w') as obj:
            obj.write('mtllib model.mtl\n'); offset=1
            for g,m in meshes.items():
                obj.write(f'o {g}\nusemtl {g}\n')
                for v,col in zip(m.vertices,m.visual.vertex_colors): obj.write('v %.6f %.6f %.6f %.4f %.4f %.4f\n'%tuple(np.r_[v,np.asarray(col[:3])/255]))
                for f in m.faces: obj.write('f %d %d %d\n'%tuple(f+offset))
                offset+=len(m.vertices)
        with (out/'model.mtl').open('w') as mtl:
            for g in meshes:
                c=np.array(colors[g][:3])/255
                mtl.write(f'newmtl {g}\nKd {c[0]:.4f} {c[1]:.4f} {c[2]:.4f}\nKa 0.05 0.05 0.05\nKs 0.12 0.12 0.12\nNs 30\n')
        cache_limit=float(settings.get('max_cache_mb',256))*1024**2
        files=sorted(self.cache.glob('*.npy'),key=lambda p:p.stat().st_mtime)
        cache_bytes=sum(p.stat().st_size for p in files)
        for path in files:
            if cache_bytes<=cache_limit: break
            size=path.stat().st_size;path.unlink();cache_bytes-=size
        report={'stage':stage,'paint_regions':len(paint),'cut_volumes':sum(p.get('role')=='cut' for p in parts),'group_grids':group_grids,'minimum_feature_adjusted_parts':adjusted_parts,
                'mesh_extraction':'shared global grid after sparse cached brick sampling','estimated_peak_grid_workspace_mb':max(x['estimated_grid_workspace_mb'] for x in group_grids.values()),'estimated_brick_working_mb':round(brick_mb,2),'cache_mb':round(cache_bytes/1024**2,2),'version':digest(doc),'detail':detail,'voxel':base_step,'grid_cells':total_cells,
                'bricks':total_bricks,'surface_bricks':active,'field_cache_hits':cache_hits,'field_samples':sampled,
                'seconds':round(time.monotonic()-tic,2),'groups':{g:{'vertices':len(m.vertices),'triangles':len(m.faces),
                'components':len(m.split(only_watertight=False)), 'watertight':bool(m.is_watertight),
                'bounds':np.round(m.bounds,3).tolist(),'area':round(float(m.area),3)} for g,m in meshes.items()},
                'skeleton':{'joint_count':len(joints),'bone_count':len(skeleton.get('bones',[])),'bones_valid':True},
                'total_triangles':sum(len(m.faces) for m in meshes.values()),'files':['model.obj','model.mtl','model.glb']}
        (out/'report.json').write_text(json.dumps(report,indent=2))
        return report

    def refine(self, detail='high', voxel=None):
        doc=self.load()
        doc.setdefault('settings',{})['detail']=detail
        if doc.get('ngl_version')==2: doc['settings']['subdivision']={'draft':1,'medium':2,'high':3}[detail]
        if voxel is not None: doc['settings']['voxel']=voxel
        return self.generate(doc)

    def inspect(self, max_faces=150000):
        from .render import render_views
        out=self.root/'build'
        return render_views(out/'model.glb',out,max_faces=max_faces)

    def export(self,destination,format='glb'):
        if format not in ('glb','obj'): raise ValueError('format must be glb or obj')
        src=self.root/'build'/f'model.{format}'
        if not src.exists(): raise FileNotFoundError('Generate the model first')
        destination=Path(destination);destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(src.read_bytes())
        if format=='obj': destination.with_suffix('.mtl').write_bytes((self.root/'build'/'model.mtl').read_bytes())
        return str(destination)


def neuro_generate(root, ngl, detail=None): return Engine(root).generate(ngl, detail)
def neuro_modify(root, edits, detail=None): return Engine(root).modify(edits, detail)
def neuro_refine(root, detail='high', voxel=None): return Engine(root).refine(detail, voxel)
def neuro_inspect(root, max_faces=150000): return Engine(root).inspect(max_faces)
def neuro_export(root, destination, format='glb'): return Engine(root).export(destination, format)

def neuro_sculpt(root, modifier):
    e=Engine(root);doc=e.load();doc.setdefault('surface_strokes' if doc.get('ngl_version')==2 else 'modifiers',[]).append(modifier)
    return e.generate(doc)


def neuro_fit_landmarks(root, observations, *, pixels_per_unit, image_size):
    from .reference import fit_landmarks
    e=Engine(root)
    if e.load().get('ngl_version')==2:
        from .cage_edit import fit_cage
        doc,fit=fit_cage(e.load(),observations,image_size=image_size,span=image_size[0]/pixels_per_unit)
    else:
        doc,fit=fit_landmarks(e.load(),observations,pixels_per_unit=pixels_per_unit,image_size=image_size)
    return {'fit':fit,'build':e.generate(doc)}
