"""Named control edits and orthographic multiview section fitting."""
import copy
import numpy as np
from scipy.optimize import least_squares


def apply_edits(doc,edits):
    doc=copy.deepcopy(doc)
    for e in edits:
        op=e['op']
        if op=='update_settings':doc.setdefault('settings',{}).update(e['changes'])
        elif op=='update_joint':
            if e['id'] not in doc.get('skeleton',{}).get('joints',{}):raise ValueError('Unknown joint')
            doc['skeleton']['joints'][e['id']]=e['position']
        elif op=='sculpt':doc.setdefault('surface_strokes',[]).append(e['stroke'])
        elif op=='remove_stroke':doc.setdefault('surface_strokes',[]).pop(int(e['index']))
        elif op in ('update_section','update_branch'):
            records=doc['cage']['sections' if op=='update_section' else 'branches']
            q=next((q for q in records if q['id']==e['id']),None)
            if q is None:raise ValueError('Unknown cage control')
            q.update(e['changes'])
        elif op=='add_branch':doc['cage'].setdefault('branches',[]).append(e['branch'])
        else:raise ValueError('Unsupported cage edit')
    return doc


def camera_basis(view):
    az,el={'front':(180,0),'left':(90,0),'right':(270,0),'rear':(0,0),'top':(180,90),'three_quarter':(140,18)}[view]
    az,el=np.deg2rad([az,el]);return np.array([[np.cos(az),-np.sin(az),0],[np.sin(az)*np.sin(el),np.cos(az)*np.sin(el),np.cos(el)]])


def fit_cage(doc, observations, *, image_size=(512,512), span=3, camera_center=(0,0,0), regularization=.01):
    """Fit annotated ring centers and projected ring extents, without image AI.
    observation: {id,view,pixel:[u,v],extent:[half_width_px,half_height_px]}.
    Pixel and/or extent may be supplied. Same calibrated camera as renderer.
    Fits center coordinates and log radii. Not full occlusion-aware image reconstruction.
    """
    if span<=0 or not observations:raise ValueError('Positive span and observations required')
    out=copy.deepcopy(doc);lookup={q['id']:q for q in out['cage']['sections']};ids=list(dict.fromkeys(o['id'] for o in observations))
    if any(i not in lookup for i in ids):raise ValueError('Unknown section landmark')
    base=np.array([lookup[i]['center']+np.log(lookup[i]['radii']).tolist() for i in ids]);index={i:k for k,i in enumerate(ids)}
    size=np.asarray(image_size,float);center=np.asarray(camera_center,float);scale=size/span
    def residual(flat):
        controls=flat.reshape(-1,5);errs=[]
        centers=np.array([q['center'] for q in out['cage']['sections']],float)
        sectionindex={q['id']:i for i,q in enumerate(out['cage']['sections'])}
        for ident,control in zip(ids,controls):centers[sectionindex[ident]]=control[:3]
        tangents=np.gradient(centers,axis=0);tangents/=np.maximum(np.linalg.norm(tangents,axis=1)[:,None],1e-10)
        frames=[];u=np.array([1.,0.,0.])
        for tangent in tangents:
            u-=u.dot(tangent)*tangent;u/=max(np.linalg.norm(u),1e-10);frames.append((u.copy(),np.cross(u,tangent)))
        for o in observations:
            q=controls[index[o['id']]];basis=camera_basis(o['view']);project=(q[:3]-center)@basis.T
            uv=size/2+project*scale*np.array([1,-1]);weight=float(o.get('weight',1))**.5
            if 'pixel' in o:errs.extend((uv-o['pixel'])*weight)
            if 'extent' in o:
                r=np.exp(q[3:]);rad=lookup[o['id']].get('radial',[1]*out['cage'].get('ring_vertices',8));a=np.arange(len(rad))*2*np.pi/len(rad)
                u,v=frames[sectionindex[o['id']]]
                ring=(r[0]*np.cos(a)*rad)[:,None]*u+(r[1]*np.sin(a)*rad)[:,None]*v
                ring+=np.asarray(lookup[o['id']].get('offsets',np.zeros((len(a),3))))
                extent=np.ptp(ring@basis.T,axis=0)/2*scale
                errs.extend((extent-o['extent'])*weight)
        errs.extend(((controls-base)*np.sqrt(regularization)*max(scale)).ravel());return np.array(errs)
    initial=residual(base.ravel());fit=least_squares(residual,base.ravel(),max_nfev=100)
    for i,q in zip(ids,fit.x.reshape(-1,5)):lookup[i]['center']=q[:3].tolist();lookup[i]['radii']=np.exp(q[3:]).tolist()
    n=sum(2*int('pixel' in o)+2*int('extent' in o) for o in observations)
    return out,{'initial_rms_pixels':float(np.sqrt(np.mean(initial[:n]**2))),'final_rms_pixels':float(np.sqrt(np.mean(residual(fit.x)[:n]**2))),'success':bool(fit.success),'controls':ids,'scope':'annotated orthographic ring landmarks and extents; not raw-photo reconstruction'}
