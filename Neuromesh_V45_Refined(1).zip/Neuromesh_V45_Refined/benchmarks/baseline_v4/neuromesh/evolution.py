"""Deterministic low-detail design variants for visual selection by ChatGPT."""
import copy,json
from pathlib import Path
import numpy as np
from .engine import Engine

def neuro_evolve(root, part_ids, count=3, seed=0, magnitude=.08):
    if not 1<=count<=12 or not 0<magnitude<=.4:raise ValueError('count 1–12; magnitude (0,.4]')
    root=Path(root);source=Engine(root).load();ids=set(part_ids)
    if not ids or not ids.issubset({p['id'] for p in source['parts']}):raise ValueError('unknown or empty part IDs')
    rng=np.random.default_rng(seed);reports=[]
    for i in range(count):
        doc=copy.deepcopy(source);doc['name']=doc.get('name','model')+f' — variation {i+1}'
        doc.setdefault('settings',{}).pop('voxel',None)
        doc['settings']['detail']='draft'
        for p in doc['parts']:
            if p['id'] not in ids:continue
            if p['kind']=='ellipsoid':
                p['radii']=(np.asarray(p['radii'])*(1+rng.uniform(-magnitude,magnitude,3))).tolist()
                p['center']=(np.asarray(p['center'])+rng.uniform(-magnitude,magnitude,3)).tolist()
            else:
                for q in p['points']:
                    q[:3]=(np.asarray(q[:3])+rng.uniform(-magnitude,magnitude,3)).tolist()
                    for k in range(3,len(q)):q[k]*=float(1+rng.uniform(-magnitude,magnitude))
        folder=root/'variations'/f'variant_{i+1:02d}'
        report=Engine(folder).generate(doc)
        reports.append({'path':str(folder),'version':report['version'],'triangles':report['total_triangles']})
    return reports
