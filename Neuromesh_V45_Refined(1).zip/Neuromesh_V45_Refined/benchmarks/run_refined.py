"""Reproducible V4/V4.5 comparisons; each cold generation has its own process."""
import argparse,copy,json,sys,subprocess,shutil,time
from pathlib import Path
import numpy as np
import trimesh
from PIL import Image,ImageDraw
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from neuromesh.engine import digest
from neuromesh.render import render_views
from neuromesh.validation import validate_scene
BASE=ROOT/'benchmarks/baseline_v4';OUT=ROOT/'benchmarks/refined'


def v4_capuchin(doc):
    d=copy.deepcopy(doc);d['name']='V4-compatible capuchin — shared core proportions, full-size ear roots'
    for b in d['cage']['branches']:
        for key in ['ring_vertices','root_scale','section_shapes']:b.pop(key,None)
        if b['id'].endswith('_ear'):
            s=1 if b['id'].startswith('right') else -1
            b['relative']=False
            b['sections']=[[s*.285,-.80,1.395,.052,.055],[s*.335,-.80,1.41,.046,.05],[s*.35,-.80,1.415,.026,.03]]
    return d


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--fresh',action='store_true');args=parser.parse_args()
    if args.fresh and OUT.exists():shutil.rmtree(OUT)
    OUT.mkdir(parents=True,exist_ok=True)
    docs={'v4_cat':json.loads((BASE/'examples/cat.v4.ngl.json').read_text()),
          'v45_cat':json.loads((ROOT/'examples/cat.v45.ngl.json').read_text()),
          'v45_capuchin':json.loads((ROOT/'examples/capuchin.v45.ngl.json').read_text())}
    docs['v4_capuchin']=v4_capuchin(docs['v45_capuchin']);results={'conditions':'same runtime, neutral gray, subdivision 3, 512 pixels per view, same cameras within each pair; cat anatomy revised; capuchin core proportions shared with V4-compatible larger ear roots','models':{}}
    for name in ['cat','capuchin']:
        result={}
        for version in ['v4','v45']:
            key=f'{version}_{name}';doc=docs[key];doc['settings'].update(subdivision=3,detail='high',max_memory_mb=512)
            source=OUT/f'{key}.ngl.json';source.write_text(json.dumps(doc,indent=2));folder=OUT/key
            measurement=folder/'measurement.json'
            if measurement.exists() and json.loads(measurement.read_text())['build']['version']==digest(doc):pass
            else:
                if folder.exists():shutil.rmtree(folder)
                module=BASE if version=='v4' else ROOT
                command=[sys.executable,str(ROOT/'benchmarks/worker.py'),str(module),str(source),str(folder)]
                if version=='v4':command.append('--diagnostic-on-rejection')
                subprocess.run(command,check=True)
            result[version]=json.loads(measurement.read_text())
        meshes=[m for v in ['v4','v45'] for m in trimesh.load(OUT/f'{v}_{name}/build/model.glb',force='scene').geometry.values()]
        bounds=np.array([m.bounds for m in meshes]);low=bounds[:,0].min(0);high=bounds[:,1].max(0)
        framing={'center':((low+high)/2).tolist(),'span':float(max(high-low)*1.15)}
        for version in ['v4','v45']:
            folder=OUT/f'{version}_{name}';t=time.perf_counter()
            render_views(folder/'build/model.glb',folder/'views',size=512,framing=framing)
            result[version]['render_seconds']=round(time.perf_counter()-t,3);result[version]['camera']=framing
            validation=validate_scene(folder/'build/model.glb');result[version]['validation']=validation
            (folder/'validation.json').write_text(json.dumps(validation,indent=2))
        sheet=Image.new('RGB',(1536,2096),(23,19,29));draw=ImageDraw.Draw(sheet)
        for i,version in enumerate(['v4','v45']):
            draw.text((18,i*1048+8),f'{name.title()} — '+('V4' if version=='v4' else 'V4.5')+(' — REJECTED: diagnostic surface' if result[version].get('generation_status','succeeded')!='succeeded' else ' — actual gray mesh'),fill=(235,235,235))
            sheet.paste(Image.open(OUT/f'{version}_{name}/views/multiview.png'),(0,i*1048+24))
        sheet.save(OUT/f'{name}_comparison.png');results['models'][name]=result
        (OUT/'results.json').write_text(json.dumps(results,indent=2))
    preview=Image.new('RGB',(1024,536),(23,19,29));draw=ImageDraw.Draw(preview)
    for i,name in enumerate(['cat','capuchin']):
        preview.paste(Image.open(OUT/f'v45_{name}/views/three_quarter.png'),(i*512,24))
        draw.text((i*512+18,6),name.title()+' — V4.5',fill=(235,235,235))
    preview.save(OUT/'preview.png')

if __name__=='__main__':main()
