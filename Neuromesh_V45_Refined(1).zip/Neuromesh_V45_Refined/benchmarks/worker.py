"""One fresh process per cold build; monitor actual RSS during generation.
Linux /proc sampling avoids an inherited fork high-water mark in getrusage.
Windows runs generation but reports RSS unavailable without an OS sampler.
"""
import sys,json,time,threading
from pathlib import Path
sys.path.insert(0,sys.argv[1])
from neuromesh import Engine
source=Path(sys.argv[2]);out=Path(sys.argv[3]);doc=json.loads(source.read_text())
stop=threading.Event();samples=[]
def rss():
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):return int(line.split()[1])/1024
    except OSError:return None

def monitor():
    while not stop.is_set():
        value=rss()
        if value is not None:samples.append(value)
        stop.wait(.005)
initial=rss();thread=threading.Thread(target=monitor,daemon=True);thread.start()
t=time.perf_counter();cpu=time.process_time()
try:
    try:report=Engine(out).generate(doc)
    except ValueError as error:
        if '--diagnostic-on-rejection' not in sys.argv or 'Surface intersects itself' not in str(error):raise
        # Preserve V4's rejection. Its own cached base and sculpt functions are
        # exported only as an explicitly invalid diagnostic comparison surface.
        import numpy as np,trimesh
        from neuromesh.cage import sculpt
        from neuromesh.engine import digest
        from neuromesh.doctor import diagnose
        from neuromesh.validation import crossing_report
        cache=list((out/'cache').glob('*.npz'))
        if len(cache)!=1:raise RuntimeError('Expected one V4 base cache for diagnostic comparison')
        data=np.load(cache[0]);mesh=trimesh.Trimesh(data['v'],data['f'],process=False)
        for stroke in doc.get('surface_strokes',[]):mesh,_=sculpt(mesh,stroke,doc['settings'].get('max_faces',160000))
        mesh.visual.vertex_colors=np.tile([174,177,180,255],(len(mesh.vertices),1))
        build=out/'build';build.mkdir(exist_ok=True)
        scene=trimesh.Scene();scene.add_geometry(mesh,geom_name='flesh');scene.export(build/'model.glb')
        mesh.export(build/'model.obj')
        validation={**diagnose(mesh),'triangle_crossings':crossing_report(mesh)}
        report={'status':'rejected_by_V4_integrity_check','diagnostic_only':True,'error':str(error),'version':digest(doc),'total_triangles':len(mesh.faces),'groups':{'flesh':validation},'kernel':'unchanged V4 cached cage and V4 sculpt functions'}
        (build/'report.json').write_text(json.dumps(report,indent=2))
finally:stop.set();thread.join()
final=rss()
measurement={'cold_generation_seconds':round(time.perf_counter()-t,3),'generation_cpu_seconds':round(time.process_time()-cpu,3),'process_peak_rss_mb':round(max(samples+[initial,final]),2) if initial is not None else None,'generation_status':report.get('status','succeeded'),'rss_sampling':'Linux VmRSS every 5 ms during generation, including imported dependencies; short spikes may be missed','build':report}
(out/'measurement.json').write_text(json.dumps(measurement,indent=2))
print(out.name,measurement['cold_generation_seconds'],measurement['process_peak_rss_mb'],report['total_triangles'],flush=True)
