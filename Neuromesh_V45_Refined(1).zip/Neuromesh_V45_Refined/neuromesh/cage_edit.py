"""Named control edits and orthographic multiview section fitting."""
import copy
import numpy as np
from scipy.optimize import least_squares


def apply_edits(doc,edits):
    doc=copy.deepcopy(doc)
    for e in edits:
        op=e['op']
        if op=='update_settings':doc.setdefault('settings',{}).update(e['changes'])
        elif op=='update_joint':
            if e['id'] not in doc.get('skeleton',{}).get('joints',{}):raise ValueError('Unknown joint')
            doc['skeleton']['joints'][e['id']]=e['position']
        elif op=='sculpt':doc.setdefault('surface_strokes',[]).append(e['stroke'])
        elif op=='remove_stroke':doc.setdefault('surface_strokes',[]).pop(int(e['index']))
        elif op in ('update_section','update_branch'):
            records=doc['cage']['sections' if op=='update_section' else 'branches']
            q=next((q for q in records if q['id']==e['id']),None)
            if q is None:raise ValueError('Unknown cage control')
            q.update(e['changes'])
        elif op=='add_branch':doc['cage'].setdefault('branches',[]).append(e['branch'])
        else:raise ValueError('Unsupported cage edit')
    return doc


def camera_basis(view):
    az,el={'front':(180,0),'left':(90,0),'right':(270,0),'rear':(0,0),'top':(180,90),'three_quarter':(140,18)}[view]
    az,el=np.deg2rad([az,el]);return np.array([[np.cos(az),-np.sin(az),0],[np.sin(az)*np.sin(el),np.cos(az)*np.sin(el),np.cos(el)]])


def fit_cage(doc, observations, *, image_size=(512,512), span=3, camera_center=(0,0,0), regularization=.01, radius_scale_bounds=(.35,2.), max_center_shift=None, area_regularization=0., robust_loss='linear', surface_level=0):
    """Fit annotated ring centers and projected ring extents, without image AI.
    observation: {id,view,pixel:[u,v],extent:[half_width_px,half_height_px]}.
    Pixel and/or extent may be supplied. Same calibrated camera as renderer.
    Fits center coordinates and log radii. Not full occlusion-aware image reconstruction.
    """
    if surface_level not in (0,1,2):raise ValueError('surface_level must be 0, 1 or 2')
    if regularization<0 or area_regularization<0:raise ValueError('Regularization must be nonnegative')
    if len(radius_scale_bounds)!=2 or not 0<radius_scale_bounds[0]<1<radius_scale_bounds[1]:raise ValueError('Radius bounds must straddle 1')
    if span<=0 or not observations:raise ValueError('Positive span and observations required')
    out=copy.deepcopy(doc);lookup={q['id']:q for q in out['cage']['sections']};ids=list(dict.fromkeys(o['id'] for o in observations))
    if any(i not in lookup for i in ids):raise ValueError('Unknown section landmark')
    base=np.array([lookup[i]['center']+np.log(lookup[i]['radii']).tolist() for i in ids]);index={i:k for k,i in enumerate(ids)}
    size=np.asarray(image_size,float);center=np.asarray(camera_center,float);scale=size/span
    def residual(flat):
        controls=flat.reshape(-1,5);errs=[]
        centers=np.array([q['center'] for q in out['cage']['sections']],float)
        sectionindex={q['id']:i for i,q in enumerate(out['cage']['sections'])}
        for ident,control in zip(ids,controls):centers[sectionindex[ident]]=control[:3]
        tangents=np.gradient(centers,axis=0);tangents/=np.maximum(np.linalg.norm(tangents,axis=1)[:,None],1e-10)
        frames=[];u=np.array([1.,0.,0.])
        for tangent in tangents:
            u-=u.dot(tangent)*tangent;u/=max(np.linalg.norm(u),1e-10);frames.append((u.copy(),np.cross(u,tangent)))
        skin_rings={}
        if surface_level:
            from .cage import compile_cage,subdivide
            candidate=copy.deepcopy(out)
            for ident,control in zip(ids,controls):
                section=next(q for q in candidate['cage']['sections'] if q['id']==ident)
                section['center']=control[:3].tolist();section['radii']=np.exp(control[3:]).tolist()
            verts,faces,labels=compile_cage(candidate)
            for _ in range(surface_level):verts,faces=subdivide(verts,faces)
            skin_rings={ident:verts[labels[ident]] for ident in ids}
        for o in observations:
            q=controls[index[o['id']]];basis=camera_basis(o['view']);project=(q[:3]-center)@basis.T
            uv=size/2+project*scale*np.array([1,-1]);weight=float(o.get('weight',1))**.5
            if surface_level:uv=size/2+((skin_rings[o['id']].mean(0)-center)@basis.T)*scale*np.array([1,-1])
            if 'pixel' in o and 'point_index' not in o:errs.extend((uv-o['pixel'])*weight)
            if 'extent' in o or 'point_index' in o:
                r=np.exp(q[3:]);rad=lookup[o['id']].get('radial',[1]*out['cage'].get('ring_vertices',8));a=np.arange(len(rad))*2*np.pi/len(rad)
                u,v=frames[sectionindex[o['id']]]
                ring=(r[0]*np.cos(a)*rad)[:,None]*u+(r[1]*np.sin(a)*rad)[:,None]*v
                ring+=np.asarray(lookup[o['id']].get('offsets',np.zeros((len(a),3))))
                if surface_level:ring=skin_rings[o['id']]-q[:3]
                extent=np.ptp(ring@basis.T,axis=0)/2*scale
                if 'extent' in o:errs.extend((extent-o['extent'])*weight)
                if 'point_index' in o:
                    k=int(o['point_index'])
                    if not 0<=k<len(ring):raise ValueError('point_index outside section ring')
                    point_uv=size/2+((q[:3]+ring[k]-center)@basis.T)*scale*np.array([1,-1])
                    errs.extend((point_uv-o['pixel'])*weight)
        if area_regularization:
            errs.extend((controls[:,3:].sum(1)-base[:,3:].sum(1))*np.sqrt(area_regularization)*max(scale))
        errs.extend(((controls-base)*np.sqrt(regularization)*max(scale)).ravel());return np.array(errs)
    initial=residual(base.ravel());lower=np.full_like(base,-np.inf);upper=np.full_like(base,np.inf)
    lower[:,3:]=base[:,3:]+np.log(radius_scale_bounds[0]);upper[:,3:]=base[:,3:]+np.log(radius_scale_bounds[1])
    if max_center_shift is not None:
        if max_center_shift<=0:raise ValueError('max_center_shift must be positive')
        lower[:,:3]=base[:,:3]-max_center_shift;upper[:,:3]=base[:,:3]+max_center_shift
    fit=least_squares(residual,base.ravel(),bounds=(lower.ravel(),upper.ravel()),loss=robust_loss,max_nfev=100)
    for i,q in zip(ids,fit.x.reshape(-1,5)):lookup[i]['center']=q[:3].tolist();lookup[i]['radii']=np.exp(q[3:]).tolist()
    n=sum(2*int('pixel' in o)+2*int('extent' in o) for o in observations)
    return out,{'initial_rms_pixels':float(np.sqrt(np.mean(initial[:n]**2))),'final_rms_pixels':float(np.sqrt(np.mean(residual(fit.x)[:n]**2))),'success':bool(fit.success),'controls':ids,'surface_level':surface_level,'radius_scale_bounds':list(radius_scale_bounds),'radius_scales':np.exp(fit.x.reshape(-1,5)[:,3:]-base[:,3:]).tolist(),'scope':'annotated orthographic ring landmarks and extents; not raw-photo reconstruction'}
