"""Conservative geometry diagnostics and repair; never invents large missing anatomy."""
import copy,json,time
from pathlib import Path
import numpy as np
import trimesh


def diagnose(mesh):
    edges=mesh.edges_sorted
    _, counts=np.unique(edges,axis=0,return_counts=True)
    area=mesh.area_faces
    duplicates=len(mesh.faces)-len(np.unique(np.sort(mesh.faces,axis=1),axis=0))
    signs=[float(c.volume) for c in mesh.split(only_watertight=False)]
    return {'vertices':int(len(mesh.vertices)),'faces':int(len(mesh.faces)),
            'boundary_edges':int(np.sum(counts==1)), 'nonmanifold_edges':int(np.sum(counts>2)),
            'degenerate_faces':int(np.sum(area<1e-12)), 'duplicate_faces':int(duplicates),
            'nonfinite_vertices':int(np.sum(~np.isfinite(mesh.vertices).all(axis=1))), 'euler_number':int(mesh.euler_number),
            'consistent_winding':bool(mesh.is_winding_consistent),
            'watertight':bool(mesh.is_watertight),
            'components':len(signs),'negative_volume_components':int(sum(v<0 for v in signs)),
            'signed_volume':round(float(mesh.volume),6),
            'self_intersections':'not measured (no robust triangle-intersection backend)'}


def neuro_doctor(input_glb, output_glb, report_path=None):
    start=time.monotonic();scene=trimesh.load(input_glb,force='scene')
    output=trimesh.Scene();report={'source':str(input_glb),'groups':{},'notes':[]}
    for name,original in scene.geometry.items():
        if not isinstance(original,trimesh.Trimesh):continue
        before=diagnose(original);mesh=original.copy();actions=[]
        finite=np.isfinite(mesh.vertices).all(axis=1)
        keep=finite[mesh.faces].all(axis=1)&(mesh.area_faces>=1e-12)
        mesh.update_faces(keep)
        _,unique=np.unique(np.sort(mesh.faces,axis=1),axis=0,return_index=True)
        if len(unique)<len(mesh.faces):mesh.update_faces(np.sort(unique));actions.append('removed duplicate triangles')
        mesh.remove_unreferenced_vertices()
        if len(mesh.faces)<before['faces']:actions.append('removed zero-area faces')
        if not mesh.is_winding_consistent or before['negative_volume_components']:
            trimesh.repair.fix_normals(mesh,multibody=True);actions.append('reoriented normals')
        if not mesh.is_watertight:
            old=mesh.faces.shape[0]
            trimesh.repair.fill_holes(mesh)
            if len(mesh.faces)>old:actions.append('filled simple boundary holes')
        # Filling a small hole can introduce faces with inconsistent orientation.
        if not mesh.is_winding_consistent or any(c.volume<0 for c in mesh.split(only_watertight=False)):
            trimesh.repair.fix_normals(mesh,multibody=True);actions.append('verified component orientation after hole repair')
        after=diagnose(mesh)
        from .validation import crossing_report
        after['triangle_crossings']=crossing_report(mesh)
        after['repair_complete']=bool(after['watertight'] and after['consistent_winding'] and not any(after[k] for k in ['boundary_edges','nonmanifold_edges','degenerate_faces','duplicate_faces','negative_volume_components','nonfinite_vertices']) and after['triangle_crossings'].get('status')=='measured' and after['triangle_crossings'].get('crossing_pairs')==0)
        output.add_geometry(mesh,geom_name=name)
        report['groups'][name]={'before':before,'after':after,'actions':actions}
    path=Path(output_glb);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(output.export(file_type='glb'))
    report['seconds']=round(time.monotonic()-start,2)
    report['notes'].append('Small topological holes can be closed; large missing regions and self-intersections require explicit modeling or a robust Boolean backend.')
    report['notes'].append('Black speckling in V1 preview arose from face-average painter sorting. A per-pixel depth buffer fixes the preview without modifying watertight geometry.')
    if report_path:Path(report_path).write_text(json.dumps(report,indent=2))
    return report
