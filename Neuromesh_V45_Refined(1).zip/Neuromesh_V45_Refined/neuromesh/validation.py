"""Budgeted triangle-crossing verification of generated surfaces.

This measures transverse intersections between nonadjacent triangles. Coplanar
overlap, tangency, and pairs sharing a vertex are explicitly outside this test.
"""
import numpy as np
import trimesh
from scipy.spatial import cKDTree
from .doctor import diagnose


def crossing_report(mesh, max_pairs=2_000_000):
    triangles = np.asarray(mesh.triangles)
    scope = 'transverse intersections; excludes shared-vertex neighbors, coplanar overlap and tangency'
    if len(triangles)==0:return {'status':'measured','crossing_pairs':0,'tested_pairs':0,'scope':scope}
    if not np.isfinite(triangles).all():return {'status':'invalid_coordinates','scope':scope}
    centers=triangles.mean(axis=1)
    radii=np.linalg.norm(triangles-centers[:,None,:],axis=-1).max(1)
    # Size-binned trees prevent one large cap triangle from expanding every query.
    bins=np.clip(np.floor(np.log2(np.maximum(radii,1e-12)/max(radii.max(),1e-12))),-16,0).astype(int)
    groups=[]
    for ident in np.unique(bins):
        indices=np.flatnonzero(bins==ident);groups.append((indices,cKDTree(centers[indices]),radii[indices].max()))
    low=triangles.min(1);high=triangles.max(1);blocks=[];candidate_count=0;broad=0
    for gi,(source,_,r0) in enumerate(groups):
        for gj in range(gi,len(groups)):
            target,tree,r1=groups[gj]
            for start in range(0,len(source),256):
                subset=source[start:start+256]
                neighbors=tree.query_ball_point(centers[subset],radii[subset]+r1)
                for i,local in zip(subset,neighbors):
                    js=target[np.asarray(local,int)]
                    if gi==gj:js=js[js>i]
                    broad+=len(js)
                    if not len(js):continue
                    keep=np.all(high[i]>=low[js]-1e-9,axis=1)&np.all(high[js]>=low[i]-1e-9,axis=1)
                    js=js[keep]
                    if not len(js):continue
                    adjacent=(mesh.faces[i][None,:,None]==mesh.faces[js][:,None,:]).any(axis=(1,2));js=js[~adjacent]
                    if len(js):blocks.append(np.column_stack([np.full(len(js),i),js]));candidate_count+=len(js)
                    if candidate_count>max_pairs:return {'status':'budget_exceeded','candidate_pairs':candidate_count,'scope':scope}
    pairs=np.concatenate(blocks) if blocks else np.empty((0,2),int)
    hits = 0;examples=[]
    def segment_hit(start, end, tri):
        direction=end-start; edge1=tri[:,1]-tri[:,0]; edge2=tri[:,2]-tri[:,0]
        h=np.cross(direction,edge2); det=np.sum(edge1*h,1)
        valid=abs(det)>1e-10; inv=np.zeros_like(det); inv[valid]=1/det[valid]
        s=start-tri[:,0]; u=inv*np.sum(s*h,1); q=np.cross(s,edge1)
        v=inv*np.sum(direction*q,1); t=inv*np.sum(edge2*q,1)
        eps=1e-7
        return valid&(u>eps)&(v>eps)&(u+v<1-eps)&(t>eps)&(t<1-eps)
    for start in range(0,len(pairs),20000):
        block=pairs[start:start+20000];a=triangles[block[:,0]];b=triangles[block[:,1]]
        hit=np.zeros(len(block),dtype=bool)
        for k in range(3):
            hit |= segment_hit(a[:,k],a[:,(k+1)%3],b)
            hit |= segment_hit(b[:,k],b[:,(k+1)%3],a)
        hits += int(hit.sum())
        if len(examples)<24:
            examples.extend(((centers[block[hit,0]]+centers[block[hit,1]])/2)[:24-len(examples)].round(4).tolist())
    return {'status':'measured','crossing_pairs':hits,'tested_pairs':len(pairs),'broadphase_pairs':broad,'broadphase':'radius-binned k-d trees','sample_crossing_centers':examples,'scope':scope}


def validate_scene(path):
    scene=trimesh.load(path,force='scene')
    return {name:{**diagnose(mesh),'triangle_crossings':crossing_report(mesh)}
            for name,mesh in scene.geometry.items() if isinstance(mesh,trimesh.Trimesh)}
