import numpy as np
import pytest

from neuromesh import Engine
from neuromesh.anatomy import Anatomy
from neuromesh.engine import field, validate_ngl


def test_anatomy_sweep_has_elliptical_cross_section():
    part = {
        'id': 'limb', 'kind': 'anatomy_sweep',
        'points': [[0, 0, 0, .3, .1], [0, 0, 1, .3, .1]],
        'group': 'flesh',
    }
    validate_ngl({'ngl_version': 1, 'parts': [part]})
    xyz = np.array([[[.2, 0, .5], [0, .2, .5], [0, 0, .5]]], dtype=np.float32)
    distances = field(part, xyz)
    assert distances[0, 0] < 0
    assert distances[0, 1] > 0
    assert distances[0, 2] < 0


def test_skeleton_compiles_persistent_named_bones(tmp_path):
    anatomy = Anatomy('test', {'detail': 'draft', 'voxel': .1, 'max_cells': 400_000})
    anatomy.joint('shoulder', [0, 0, .6])
    anatomy.joint('elbow', [0, 0, 0])
    anatomy.bone('upper_arm', 'shoulder', 'elbow', [.18, .1], [.1, .08])
    anatomy.ellipsoid('torso', [0, 0, .4], [.35, .25, .5])
    report = Engine(tmp_path).generate(anatomy.build())
    assert report['skeleton'] == {'joint_count': 2, 'bone_count': 1, 'bones_valid': True}
    assert 'bone_upper_arm' in {p['id'] for p in Engine(tmp_path).load()['parts']}
    assert report['groups']['flesh']['watertight']


def test_skeleton_rejects_unknown_joint(tmp_path):
    anatomy = Anatomy()
    anatomy.joint('a', [0, 0, 0])
    anatomy.bone('bad', 'a', 'missing', [.1, .1], [.1, .1])
    with pytest.raises(KeyError):
        Engine(tmp_path).generate(anatomy.build())
