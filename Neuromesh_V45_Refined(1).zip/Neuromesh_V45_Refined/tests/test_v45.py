import copy
import numpy as np
import trimesh
from neuromesh.cage import compile_cage,subdivide,triangulate,sculpt
from neuromesh.doctor import neuro_doctor
from neuromesh.validation import crossing_report
from neuromesh.cage_edit import fit_cage,camera_basis
from test_v4 import model


def test_denser_branch_shared_boundary_and_shape():
    d=model();b=d['cage']['branches'][0];b['ring_vertices']=8
    b['sections']=[{'center':[.8,.4,-.7],'radii':[.2,.2],'power':2.8},{'center':[1,.4,-1.1],'radii':[.1,.08],'power':2.6}]
    v,f,_=compile_cage(d);v,f=subdivide(v,f);m=triangulate(v,f)
    assert m.is_watertight and m.euler_number==2 and m.is_winding_consistent
    assert crossing_report(m)['crossing_pairs']==0


def test_brush_orientation_mask_and_displacement_cap():
    m=trimesh.creation.icosphere(subdivisions=2)
    stroke={'op':'grab','center':[0,0,1.0],'radius':1.8,'radii':[.8,.8,1.8],
      'vector':[.3,0,0],'facing':[0,0,1],'normal_angle':75,'max_displacement':.025,'falloff':1}
    edited,_=sculpt(m,stroke,10000);distance=np.linalg.norm(edited.vertices-m.vertices,axis=1)
    assert distance.max()<=.025+1e-12 and distance.max()>0
    assert np.allclose(edited.vertices[m.vertices[:,2]<0],m.vertices[m.vertices[:,2]<0])


def test_doctor_duplicate_and_individual_negative_component(tmp_path):
    a=trimesh.creation.icosphere(subdivisions=1,radius=2)
    b=trimesh.creation.icosphere(subdivisions=1,radius=.5);b.invert();b.apply_translation([4,0,0])
    mesh=trimesh.util.concatenate([a,b]);mesh.faces=np.vstack([mesh.faces,mesh.faces[-1]])
    source=tmp_path/'source.glb';trimesh.Scene(mesh).export(source)
    r=neuro_doctor(source,tmp_path/'repaired.glb');g=next(iter(r['groups'].values()))
    assert g['before']['duplicate_faces']==1
    assert g['after']['duplicate_faces']==0 and g['after']['negative_volume_components']==0
    assert g['after']['repair_complete'] and g['after']['components']==2


def test_binned_crossing_with_heterogeneous_triangle_sizes():
    v=[[-1,-1,0],[1,-1,0],[0,1,0],[0,0,-1],[.3,0,1],[-.3,.4,1],[-100,50,0],[100,50,0],[0,200,0]]
    m=trimesh.Trimesh(v,[[0,1,2],[3,4,5],[6,7,8]],process=False)
    r=crossing_report(m);assert r['status']=='measured' and r['crossing_pairs']==1
    assert crossing_report(trimesh.Trimesh())['crossing_pairs']==0


def test_subdivided_reference_points_and_bounds():
    target=model();v,f,labels=compile_cage(target);v,f=subdivide(v,f);basis=camera_basis('front')
    observations=[]
    for k in [0,2,4,6]:
        xyz=v[labels['b'][k]];uv=256+(xyz@basis.T)*512/3*np.array([1,-1])
        observations.append({'id':'b','view':'front','point_index':k,'pixel':uv.tolist()})
    source=copy.deepcopy(target);source['cage']['sections'][1]['radii']=[.51,.425]
    fitted,r=fit_cage(source,observations,span=3,surface_level=1,regularization=1e-5,radius_scale_bounds=(.7,1.4),max_center_shift=.15)
    assert r['final_rms_pixels']<.05 and r['final_rms_pixels']<r['initial_rms_pixels']/30
    assert all(.7<=s<=1.4 for s in r['radius_scales'][0])
    assert source['cage']['sections'][1]['radii']==[.51,.425]


def test_small_attachment_footprint_stays_connected():
    d=model();d['cage']['branches'][0].update(root_scale=.55,ring_vertices=8)
    v,f,_=compile_cage(d);v,f=subdivide(v,f);m=triangulate(v,f)
    assert m.is_watertight and m.is_winding_consistent and m.euler_number==2
    assert crossing_report(m)['crossing_pairs']==0


def test_doctor_positive_total_volume_does_not_hide_inverted_shell(tmp_path):
    a=trimesh.creation.icosphere(subdivisions=1,radius=1)
    b=trimesh.creation.icosphere(subdivisions=1,radius=.35);b.invert();b.apply_translation([3,0,0])
    mesh=trimesh.util.concatenate([a,b])
    assert mesh.is_winding_consistent and mesh.volume>0
    source=tmp_path/'mixed.glb';trimesh.Scene(mesh).export(source)
    r=neuro_doctor(source,tmp_path/'fixed.glb');g=next(iter(r['groups'].values()))
    assert g['before']['negative_volume_components']==1
    assert g['after']['negative_volume_components']==0 and g['after']['repair_complete']
