import copy, json
from pathlib import Path
import numpy as np
import pytest
import trimesh
from neuromesh import Engine
from neuromesh.engine import field, validate_ngl


def small():
    return {'ngl_version':1,'settings':{'detail':'draft','voxel':.1},'parts':[
        {'id':'body','kind':'ellipsoid','center':[0,0,0],'radii':[.7,.45,.9],'group':'flesh','blend':.12},
        {'id':'tail','kind':'sweep','points':[[0,0,-.6,.2],[0,0,-1.25,.13],[.3,0,-1.6,.06]],'group':'flesh','blend':.16}]}


def test_field_sign_and_validation():
    p=small()['parts'][0]
    v=field(p,np.array([[[0,0,0],[3,0,0]]],dtype=np.float32))
    assert v[0,0]<0<v[0,1]
    with pytest.raises(ValueError):validate_ngl({'ngl_version':1,'parts':[p,p]})


def test_generate_cache_modify_rollback_export(tmp_path):
    e=Engine(tmp_path)
    first=e.generate(small())
    assert first['total_triangles']>100
    assert first['groups']['flesh']['watertight']
    assert (tmp_path/'build'/'model.glb').stat().st_size>500
    second=e.build()
    assert second['field_samples']==0 and second['field_cache_hits']>0
    changed=e.modify([{'op':'update','id':'body','changes':{'radii':[.85,.45,.9]}}])
    assert changed['version']!=first['version']
    assert changed['field_cache_hits']>0 and changed['field_samples']>0
    restored=e.rollback(first['version'])
    assert restored['version']==first['version']
    exported=e.export(tmp_path/'copies'/'test.obj', 'obj')
    assert Path(exported).exists() and Path(exported).with_suffix('.mtl').exists()
    loaded=trimesh.load(tmp_path/'build'/'model.glb',force='scene')
    assert sum(len(m.faces) for m in loaded.geometry.values())>100


def test_memory_budget(tmp_path):
    doc=small();doc['settings']['max_cells']=100
    with pytest.raises(MemoryError): Engine(tmp_path).generate(doc)
