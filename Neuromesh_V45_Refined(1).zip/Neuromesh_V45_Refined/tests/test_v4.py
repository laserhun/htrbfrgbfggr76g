import copy, json
import numpy as np
import pytest
from neuromesh import Engine
from neuromesh.cage import compile_cage,subdivide,triangulate,sculpt,local_subdivide
from neuromesh.cage_edit import fit_cage,camera_basis
from neuromesh.validation import crossing_report


def model():
    return {'ngl_version':2,'settings':{'subdivision':1},'cage':{'sections':[
      {'id':'a','center':[0,-1,0],'radii':[.5,.5]},
      {'id':'b','center':[0,0,0],'radii':[.6,.5]},
      {'id':'c','center':[0,1,0],'radii':[.4,.4]}],
      'branches':[{'id':'limb','attach':'b:7','sections':[[.8,.4,-.7,.2,.2],[1,.4,-1.1,.1,.1]]}]}}


def test_shared_junction_and_subdivision():
    v,f,ids=compile_cage(model());m=triangulate(v,f)
    assert m.is_watertight and len(m.split())==1
    assert m.euler_number==2
    v,f=subdivide(v,f);m=triangulate(v,f)
    assert m.is_watertight and m.is_winding_consistent and m.euler_number==2
    assert crossing_report(m)['crossing_pairs']==0


def test_local_refinement_is_conforming_and_preserves_geometry():
    v,f,_=compile_cage(model());v,f=subdivide(v,f);m=triangulate(v,f)
    r=local_subdivide(m,np.array([0,-.6,0]),.6)
    assert r.is_watertight and r.is_winding_consistent
    assert len(r.faces)>len(m.faces)
    assert r.volume==pytest.approx(m.volume,abs=1e-9)
    assert r.euler_number==m.euler_number


def test_all_surface_brushes_locality():
    v,f,_=compile_cage(model());v,f=subdivide(v,f);m=triangulate(v,f)
    c=m.vertices[10].copy()
    for op in ['grab','clay','crease','flatten','smooth','pinch','inflate','carve']:
        r,scale=sculpt(m,{'op':op,'center':c.tolist(),'radius':.4,'strength':.015,'vector':[.01,.015,0]},10000)
        assert r.is_watertight and np.isfinite(r.vertices).all()
        assert np.allclose(r.vertices[np.linalg.norm(m.vertices-c,axis=1)>.4],m.vertices[np.linalg.norm(m.vertices-c,axis=1)>.4])
        assert not np.allclose(r.vertices,m.vertices)
        assert 0<scale<=1


def test_history_cache_and_budget(tmp_path):
    e=Engine(tmp_path);a=e.generate(model());assert not a['cage_cache_hit']
    assert e.build()['cage_cache_hit']
    b=e.modify([{'op':'update_section','id':'b','changes':{'radii':[.7,.5]}}]);assert b['version']!=a['version']
    e.rollback(a['version']);assert e.load()==model()
    d=model();d['settings']['max_faces']=5
    with pytest.raises(MemoryError):e.generate(d)
    assert e.load()==model()


def test_multiview_center_and_extent_fit():
    d=model();target=[.13,.24,.18];r=[.7,.6];size=512;span=3
    observations=[]
    for view in ['front','left','top']:
        basis=camera_basis(view);uv=np.array(target)@basis.T*size/span*np.array([1,-1])+size/2
        a=np.arange(8)*2*np.pi/8;ring=np.column_stack([r[0]*np.cos(a),np.zeros(8),r[1]*np.sin(a)])
        ext=np.ptp(ring@basis.T,axis=0)/2*size/span
        observations.append({'id':'b','view':view,'pixel':uv.tolist(),'extent':ext.tolist()})
    new,report=fit_cage(d,observations,span=span,regularization=1e-5)
    assert report['final_rms_pixels']<.01
    assert np.allclose(new['cage']['sections'][1]['center'],target,atol=.001)
    assert np.allclose(new['cage']['sections'][1]['radii'],r,atol=.001)
    assert d==model()


def test_skeleton_drives_surface_and_distant_controls_stay_fixed():
    d=model();d['skeleton']={'joints':{'elbow':[.8,.4,-.7],'wrist':[1,.4,-1.1]},'bones':[{'start':'elbow','end':'wrist'}]}
    d['cage']['branches'][0]['sections']=[{'joint':'elbow','radii':[.2,.2]},{'joint':'wrist','radii':[.1,.1]}]
    from neuromesh.cage_edit import apply_edits
    v,f,_=compile_cage(d);changed=apply_edits(d,[{'op':'update_joint','id':'wrist','position':[1.1,.4,-1.1]}]);v2,f2,_=compile_cage(changed)
    assert np.array_equal(v[:24],v2[:24]) and not np.array_equal(v[-4:],v2[-4:])
    v,f=subdivide(v,f);v2,f2=subdivide(v2,f2)
    assert np.array_equal(v[:8],v2[:8])


def test_brush_does_not_jump_to_remote_surface():
    v,f,_=compile_cage(model());v,f=subdivide(v,f);mesh=triangulate(v,f)
    edited,_=sculpt(mesh,{'op':'grab','center':[50,50,50],'radius':.2,'vector':[1,0,0]},10000)
    assert np.array_equal(edited.vertices,mesh.vertices)
