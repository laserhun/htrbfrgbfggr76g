import copy,json
from pathlib import Path
import numpy as np
import pytest
import trimesh
from neuromesh import Engine,neuro_doctor,fit_landmarks
from neuromesh.render import render_views


def test_profile_sweep_and_sculpt(tmp_path):
    doc={'ngl_version':1,'settings':{'voxel':.09},'parts':[
      {'id':'body','kind':'profile_sweep','points':[[0,0,-.6,.12,.12],[0,0,0,.42,.3],[0,0,.7,.03,.03]],'group':'flesh','blend':.12}],
      'modifiers':[{'op':'inflate','center':[.3,0,0],'radius':.4,'strength':.08},
                   {'op':'grab','center':[0,0,.4],'radius':.5,'vector':[.04,0,0]}]}
    r=Engine(tmp_path).generate(doc)
    assert r['groups']['flesh']['watertight']
    assert r['groups']['flesh']['components']==1
    doc2=copy.deepcopy(doc);doc2['modifiers'].append({'op':'carve','center':[.3,0,0],'radius':.3,'strength':.04})
    r2=Engine(tmp_path).generate(doc2)
    assert r2['field_cache_hits']>0


def test_doctor_diagnoses_actual_boundary(tmp_path):
    m=trimesh.creation.icosphere(subdivisions=2)
    m.update_faces(np.arange(len(m.faces))!=0)
    p=tmp_path/'broken.glb';trimesh.Scene(m).export(p)
    r=neuro_doctor(p,tmp_path/'fixed.glb')
    g=next(iter(r['groups'].values()))
    assert g['before']['boundary_edges']==3
    assert g['after']['boundary_edges']==0


def test_reference_landmarks():
    doc={'ngl_version':1,'parts':[{'id':'head','kind':'ellipsoid','center':[0,0,0],'radii':[1,1,1]}]}
    new,r=fit_landmarks(doc,[{'id':'head','view':'front','pixel':[45,45]},{'id':'head','view':'left','pixel':[50,45]}],pixels_per_unit=100,image_size=[100,100])
    assert new['parts'][0]['center'][0]>.04 and new['parts'][0]['center'][2]>.04
    assert r['rms_pixel_error']<.3


def test_no_face_dropping(tmp_path):
    scene=trimesh.Scene(trimesh.creation.icosphere(subdivisions=2));p=tmp_path/'m.glb';p.write_bytes(scene.export(file_type='glb'))
    with pytest.raises(ValueError,match='false holes'):render_views(p,tmp_path/'view',max_faces=20,size=64)


def test_variations_preserve_source(tmp_path):
    from neuromesh import neuro_evolve
    doc={'ngl_version':1,'settings':{'detail':'draft'},'parts':[{'id':'mass','kind':'ellipsoid','center':[0,0,0],'radii':[.4,.4,.4]}]}
    Engine(tmp_path).generate(doc)
    before=Engine(tmp_path).load()
    candidates=neuro_evolve(tmp_path,['mass'],count=2,seed=7)
    assert len(candidates)==2 and candidates[0]['version']!=candidates[1]['version']
    assert Engine(tmp_path).load()==before
