import copy
import numpy as np
import trimesh
from neuromesh.engine import Engine, field
from neuromesh.reference import loft_from_silhouettes
from neuromesh.validation import crossing_report


def document():
    return {'ngl_version':1,'settings':{'voxel':.09,'detail':'draft'},'parts':[
        {'id':'body','kind':'loft','points':[[0,0,0,.3,.22],[0,.3,.35,.35,.25],[.15,.6,.7,.22,.19]],'blend':.1},
        {'id':'socket','kind':'ellipsoid','center':[0,-.17,.1],'radii':[.14,.17,.12],'role':'cut','blend':.02,'stage':'secondary'},
        {'id':'paint','kind':'ellipsoid','center':[0,0,.2],'radii':[.6,.6,.6],'role':'paint','color':[240,20,30]}]}


def test_continuous_loft_sign_and_rounded_cap():
    p=document()['parts'][0]
    assert field(p,np.array([[0,0,-.12]],'f4'))[0]<0
    assert field(p,np.array([[0,0,-1]],'f4'))[0]>0
    assert np.isfinite(field(p,np.random.default_rng(4).normal(size=(100,3)).astype('f4'))).all()


def test_subtraction_stage_and_paint(tmp_path):
    e=Engine(tmp_path);doc=document()
    carved=e.generate(doc)
    mesh=trimesh.load(tmp_path/'build/model.glb',force='scene').geometry['flesh']
    assert mesh.is_watertight and mesh.is_winding_consistent
    assert np.max(mesh.visual.vertex_colors[:,0])>200
    doc['settings']['max_stage']='primary'
    report=e.generate(doc)
    uncarved=trimesh.load(tmp_path/'build/model.glb',force='scene').geometry['flesh']
    assert report['cut_volumes']==0 and carved['cut_volumes']==1
    assert uncarved.volume>mesh.volume
    doc['parts']=[p for p in doc['parts'] if p.get('role')!='paint']
    e.generate(doc)
    no_paint=trimesh.load(tmp_path/'build/model.glb',force='scene').geometry['flesh']
    assert np.allclose(uncarved.vertices,no_paint.vertices)


def test_reference_profiles_and_crossing_detection():
    p=loft_from_silhouettes('torso',[[0,-1,1],[1,-.5,.5]],[[0,-.3,.7],[1,-.2,.2]])
    assert np.allclose(p['points'][0],[0,.2,0,1,.5])
    mesh=trimesh.Trimesh(vertices=[[-1,-1,0],[1,-1,0],[0,1,0],[0,0,-1],[.3,0,1],[-.3,.4,1]],faces=[[0,1,2],[3,4,5]],process=False)
    assert crossing_report(mesh)['crossing_pairs']==1


def test_local_group_resolution_retains_small_eye(tmp_path):
    doc={'ngl_version':1,'settings':{'voxel':.1,'detail':'draft','group_voxel':{'pupil':.012}},'parts':[
        {'id':'body','kind':'ellipsoid','center':[0,0,0],'radii':[.3,.3,.3]},
        {'id':'tiny_eye','kind':'ellipsoid','center':[0,-.35,0],'radii':[.022,.016,.02],'group':'pupil'}]}
    report=Engine(tmp_path).generate(doc)
    assert report['group_grids']['pupil']['voxel']==.012
    assert report['groups']['pupil']['watertight'] and report['groups']['pupil']['triangles']>30
    assert report['group_grids']['pupil']['cells']<report['group_grids']['flesh']['cells']*10
