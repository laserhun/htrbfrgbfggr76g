"""V4.5 authored anatomy. Species decisions live in data, outside the kernel."""
import json,copy
from pathlib import Path
from forge_designs import document,branch,add_skeleton,cat as forge_cat


def cat():
    d=forge_cat();d['name']='Refined cat — lean torso, shaped paws, shorter facial profile'
    profiles={'nose':(-1.105,1.12,.055,.046),'muzzle':(-1.065,1.13,.112,.076),
      'cheek':(-.985,1.21,.240,.181),'skull':(-.85,1.255,.245,.212),
      'occiput':(-.70,1.23,.205,.206),'neck':(-.585,1.07,.178,.201),
      'withers':(-.44,.98,.237,.258),'scapula':(-.26,.925,.25,.267),
      'ribs':(-.03,.89,.232,.267),'waist':(.24,.87,.180,.217),
      'pelvis':(.45,.885,.253,.254),'sacrum':(.65,.91,.208,.19)}
    for q in d['cage']['sections']:
        if q['id'] in profiles:
            y,z,xr,zr=profiles[q['id']];q['center']=[0,y,z];q['radii']=[xr,zr]
    for b in d['cage']['branches']:
        if b['id'].endswith('ear'):
            for q in b['sections']:d['skeleton']['joints'][q['joint']][2]-=.075
            b['sections'][0]['radii']=[.11,.060]
            b['sections'][1]['radii']=[.072,.035]
        else:
            b['ring_vertices']=8
            for i,q in enumerate(b['sections']):
                q['radii']=[x*(.78 if i==0 else .85) for x in q['radii']]
                if i>=3:q['power']=2.8
    # Actual shallow facial modeling, with a directional and elliptical brush mask.
    d['surface_strokes']=[{'op':'crease','center':[0,-1.075,1.097],'radius':.115,
      'strength':.016,'width':.008,'normal':[0,0,1],'facing':[0,-1,0],'normal_angle':95,'falloff':1.2}]
    for s in [-1,1]:
        d['surface_strokes'].append({'op':'carve','center':[s*.125,-1.047,1.305],
          'radius':.11,'radii':[.082,.12,.062],'strength':.045,'facing':[0,-1,0],'normal_angle':95,'falloff':1.})
    return d


def capuchin():
    d=document('Refined capuchin — compact face, light torso, opposing thumbs',[
     ('nose',-1.10,1.22,.062,.048),('muzzle',-1.05,1.20,.105,.080),
     ('face',-.99,1.29,.190,.184),('skull',-.85,1.35,.221,.230),('occiput',-.70,1.34,.202,.218),
     ('neck',-.57,1.14,.148,.188),('withers',-.39,.965,.212,.251),('scapula',-.20,.89,.215,.233),
     ('ribs',.02,.83,.191,.226),('waist',.27,.79,.155,.188),('pelvis',.45,.775,.204,.219),
     ('sacrum',.63,.765,.172,.152),('tail_root',.80,.83,.065,.066),('tail_a',.99,.94,.052,.049),
     ('tail_b',1.24,1.07,.044,.043),('tail_c',1.45,1.26,.036,.037),('tail_d',1.47,1.49,.032,.031),
     ('tail_e',1.28,1.65,.027,.027),('tail_f',1.06,1.63,.022,.022),('tail_tip',.975,1.48,.010,.012)])
    for q in d['cage']['sections']:
        if q['id'] in ['face','skull']:q['radial']=[1.08,.94,1.,.94,1.08,.95,.95,.95]
    for s,label,k in [(1,'right',7),(-1,'left',4)]:
        branch(d,label+'_arm',f'withers:{k}',[[s*.243,-.325,.655,.105,.095],
         [s*.26,-.48,.435,.065,.061],[s*.28,-.65,.25,.046,.049],
         [s*.285,-.73,.132,.039,.040],[s*.285,-.82,.095,.078,.036],[s*.285,-.91,.09,.076,.032]])
        for i,q in enumerate(d['cage']['branches'][-1]['sections']):
            if i>=4:d['cage']['branches'][-1].setdefault('section_shapes',{})[str(i)]={'power':2.6,'phase':.7853981634}
        branch(d,label+'_leg',f'pelvis:{k}',[[s*.236,.45,.56,.134,.119],
         [s*.255,.18,.37,.088,.079],[s*.268,.46,.19,.05,.058],[s*.27,.44,.10,.049,.048],
         [s*.27,.31,.073,.086,.049],[s*.27,.22,.072,.073,.040]])
        d['cage']['branches'][-1]['ring_vertices']=8
        branch(d,label+'_ear','skull:'+str(0 if s==1 else 3),[[s*.27,-.78,1.42,.046,.05],
         [s*.285,-.78,1.43,.043,.048],[s*.29,-.78,1.435,.023,.026]])
        d['cage']['branches'][-1].update(ring_vertices=8,root_scale=.38)
    for s,label in [(1,'right'),(-1,'left')]:
        for i in range(4):
            branch(d,f'{label}_digit_{i}',f'{label}_arm:cap:strip:{i}',[[0,-.046,0,.014,.013],
              [0,-.100,-.004,.012,.011],[0,-.143,-.002,.008,.008]])
            d['cage']['branches'][-1].update(relative=True,ring_vertices=8)
        branch(d,label+'_thumb',label+'_arm:3:auto',[[s*.39,-.79,.112,.027,.024],
           [s*.415,-.84,.10,.022,.021],[s*.405,-.90,.097,.014,.016]])
        d['cage']['branches'][-1]['ring_vertices']=8
    import sys,numpy as np
    sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
    from neuromesh.cage import compile_cage
    bare=copy.deepcopy(d);bare['cage']['branches']=[]
    verts,_,labels=compile_cage(bare);skull=labels['skull'];occiput=labels['occiput']
    for b in d['cage']['branches']:
        if not b['id'].endswith('_ear'):continue
        k=int(b['attach'].split(':')[-1]);ids=[skull[k],occiput[k],occiput[(k+1)%8],skull[(k+1)%8]]
        points=verts[ids];normal=np.cross(points[1]-points[0],points[2]-points[0]);normal/=np.linalg.norm(normal)
        b['sections']=[[*((normal*t)),rx,rz] for t,rx,rz in [(.04,.034,.039),(.065,.036,.041),(.080,.019,.025)]]
        b['relative']=True
    add_skeleton(d)
    d['surface_strokes']=[{'op':'crease','center':[0,-1.072,1.185],'radius':.125,'strength':.021,
        'width':.008,'normal':[0,0,1],'facing':[0,-1,0],'normal_angle':100,'falloff':1.2}]
    for s in [-1,1]:
        d['surface_strokes'].append({'op':'carve','center':[s*.119,-1.061,1.38],'radius':.14,
          'radii':[.082,.12,.069],'strength':.065,'facing':[0,-1,0],'normal_angle':100,'falloff':1.})
    return d


if __name__=='__main__':
    for n,fn in [('cat',cat),('capuchin',capuchin)]:Path(__file__).with_name(n+'.v45.ngl.json').write_text(json.dumps(fn(),indent=2))
