# Neuromesh V4.5 — benchmark report

| Model | Release | Triangles | Build/attempt time | Sampled peak RSS | Result |
|---|---|---:|---:|---:|---|
| Cat | V4 | 32,256 | 1.91 s | 118.0 MB | Closed, zero measured crossings |
| Cat | V4.5 | 45,568 | 3.00 s | 185.1 MB | Closed, zero measured crossings |
| Capuchin | V4 | 51,840 | Failed; diagnostic | 255.3 MB | Rejected, 45 crossings |
| Capuchin | V4.5 | 80,640 | 6.10 s | 258.3 MB | Closed, zero measured crossings |

29 tests passed: 28 in the full compatibility/regression run, plus the independently executed inverted-component regression. Editable installation reports version 0.4.5.

V4 source is unchanged and frozen in the ZIP. Cat V4 is its published design. Capuchin core body proportions are shared; V4-compatible ear extrusions use full-size root patches, while V4.5 uses smaller footprints. Both comparisons use the same six-view CPU renderer, neutral gray and pair-matched framing. No external reference photographs were supplied. Anatomy changes are authored instructions, not an automatic anatomy-learning system.

The V4 capuchin was refused by its own intersection check. The explicitly labeled diagnostic surface reuses V4's cached cage and applies its original sculpt functions; it is not a successful generation or a repaired baseline. Its attempt timing includes diagnostic reconstruction and is not comparable with successful V4.5 build timing.

Memory is Linux VmRSS sampled every 5 ms during generation, including dependencies; short spikes may be missed. CPU times are hosted-runtime measurements, not i5-6500 measurements. The new query broadphase avoids oversized candidates, but denser cages and extra brush calculations can outweigh that saving.

Both V4.5 models have one closed connected skin, consistent winding, positive volume, and no boundary/nonmanifold edges, duplicates or zero-area faces. The crossing checker measures proper transverse intersections and excludes coplanar overlap, tangency and shared-vertex neighbors. Its zero count is not a complete intersection certificate.

Visual assessment: body proportions and junction control improve, but faces, ears and paws remain simplified. The outputs still have primitive-looking features and do not establish realistic cat/capuchin reconstruction. The geometry doctor repairs simple defects, not arbitrary intersections or missing anatomy. See CHANGELOG.md and README.md for implemented controls and limitations.
