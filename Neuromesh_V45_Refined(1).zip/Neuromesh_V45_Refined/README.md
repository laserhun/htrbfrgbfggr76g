# Neuromesh V4.5 — Refined

A focused CPU update to V4. ChatGPT remains the creative intelligence; the engine executes geometry instructions. No additional neural models, cloud GPUs, Blender, or paid AI APIs.

## Changes

- Denser shared branch roots, controllable attachment footprints, and noncircular section profiles improve paws, small ears, and limb transitions. Bisector section frames reduce kinks at bent joints. The control-cage/subdivision architecture is retained.
- Brushes seed from the closest triangle point rather than a snapped vertex. Optional elliptical masks, facing limits, falloff, and displacement caps improve local control.
- The doctor removes duplicate triangles and fixes individually inverted components, including when total scene volume is positive. It rechecks orientation after small-hole repair and reports unresolved crossings.
- Size-binned intersection queries reduce unnecessary broadphase work. Cage builds reuse their initial control compile rather than compiling twice.
- Existing reference fitting adds bounds, robust losses, optional area regularization, ring-point landmarks, and optional subdivision-aware landmark fitting.

NGL 1, NGL 2, all five supertools, regional refinement, version history, rollback, GLB and OBJ export remain available. V4 source is frozen under `benchmarks/baseline_v4`. Shapes can change when rebuilt because joint frames are improved; rollback restores instructions using the current kernel.

## Installation and phone workflow

Use Python 3.10+ on 64-bit Windows or Linux. Windows PowerShell, inside the extracted folder:

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -e ".[test]"
python -m pytest tests -q
python -m neuromesh --project my_capuchin generate examples/capuchin.v45.ngl.json
python -m neuromesh --project my_capuchin inspect
python -m neuromesh --project my_capuchin export capuchin.glb --format glb
```

For Linux, use `python3 -m venv .venv` and `source .venv/bin/activate`. A ChatGPT execution environment with the dependencies can run the package while the phone handles conversation. The package does not establish a phone-to-PC connection. Included GLBs and PNGs require no Python installation to view.

## Focused modeling controls

Existing NGL examples remain valid. The new authored designs are `examples/cat.v45.ngl.json` and `examples/capuchin.v45.ngl.json`; `examples/refined_designs.py` reproduces them. Species-specific proportions live in examples, not in the engine.

A branch can specify `ring_vertices: 8` and `root_scale: 0.45`. Densification shares added boundary vertices with neighboring faces. `root_scale` retains the surrounding skin and shrinks the actual attachment footprint. Branch section dictionaries accept `center` or `joint`, `radii`, and optional `power`, `profile`, and `phase`. `power` 2 is an elliptical profile; larger values make fuller corners. `profile` contains one positive radial factor per resolved ring vertex. `phase` rotates the section in its transverse frame. Existing numeric sections remain supported. A branch's `section_shapes` map provides the same shape controls by section index.

```python
from neuromesh import Engine, neuro_sculpt, fit_cage

engine = Engine('my_capuchin')
engine.modify([{'op':'update_section','id':'waist',
                'changes':{'radii':[0.15,0.18]}}])
neuro_sculpt('my_capuchin', {
    'op':'carve', 'center':[0.12,-1.06,1.38], 'radius':0.12,
    'radii':[0.08,0.12,0.07], 'facing':[0,-1,0],
    'normal_angle':90, 'falloff':1, 'strength':0.03,
    'max_displacement':0.025
})

# ChatGPT/user supplies calibrated image annotations.
fitted, fit_report = fit_cage(engine.load(), [
    {'id':'waist','view':'front','point_index':0,'pixel':[230,240]},
    {'id':'waist','view':'left','pixel':[245,240]}
], image_size=(512,512), span=3, camera_center=(0,0,0.8),
   surface_level=1, radius_scale_bounds=(0.7,1.4),
   max_center_shift=0.15, robust_loss='soft_l1')
# Inspect fit_report before generating fitted instructions.
```

`surface_level` 0 fits control rings; 1 or 2 fits their subdivided landmark positions. `point_index` names an angular ring vertex. This improves prediction of subdivision shrinkage, but does not optimize a raw-photo silhouette mask. `radii` brush coordinates are world XYZ; `facing` masks by surface-normal direction. Normal masks are optional, so original brush calls work.

Use `neuro_generate`, `neuro_modify`, `neuro_inspect`, `neuro_refine`, and `neuro_export` as before. Draft/medium/high subdivision presets remain 1/2/3. `Engine.rollback(version_hash)` restores a previous instruction version.

## Benchmarks and limits

Read `CHANGELOG.md` for short results. `benchmarks/refined` contains six-view comparisons, actual GLBs/OBJs, timings, sampled RSS, validation, and editable instructions. The coarse inspections are preserved separately. Reproduce with `python benchmarks/run_refined.py --fresh`; this clears only generated comparison output. Without `--fresh`, existing matching cold measurements are reused. Tests cover original functionality and the new controls/repair/fitting behavior.

The V4 capuchin comparison is explicitly a **rejected diagnostic surface**, exported from V4's own cached cage and sculpt functions after its integrity check refused it. Its caption and report preserve that failure; it is not counted as a successful V4 generation. Cat V4 is the published V4 design. Comparisons use neutral material and matched six-view cameras. Capuchin core proportions are shared, with V4-compatible larger ear roots; cat anatomical controls are revised.

Both animals remain simplified procedural models. Their faces, ears and paws are not convincing realistic anatomy. These renders do not establish Meshy quality or accurate species reconstruction. No reference photos were supplied.

Validation checks boundaries, manifoldness, duplicates, degeneracy, winding, components, volume, and proper transverse crossings. The crossing test excludes coplanar overlap, tangencies, and shared-vertex neighbors. The doctor does not automatically resolve arbitrary intersections or reconstruct large missing anatomy. Clean meshes and subdivision are not animation-ready topology. There are no UVs, rigging, fur, automatic image inference or autonomous LLM execution bridge.

Memory/face/cache guards use algorithmic workspace estimates, not an OS RSS cap. Benchmark memory is sampled Linux process RSS during generation; short spikes may be missed. Actual timings are hosted-CPU measurements, not measurements on an i5-6500. The denser cages and precise facial strokes can outweigh broadphase savings, so V4.5 is not universally faster than V4.
